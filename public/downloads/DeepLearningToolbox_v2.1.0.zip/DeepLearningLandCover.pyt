﻿# -*- coding: utf-8 -*-
"""
Deep Learning Land Cover Classification Toolbox
Author: ArcGIS Pro
Version: 2.1
Date: 2026
"""

import arcpy
import os
import sys
import urllib.request
import zipfile
import subprocess
import shutil
import urllib.error
import json
import site
import time
import warnings
import platform
import traceback
import importlib
import tempfile
from pathlib import Path
import uuid
import urllib.parse
import getpass
import random
import ctypes
import base64
from datetime import datetime, timezone

warnings.filterwarnings('ignore')

def get_python_exe():
    """Get the correct python executable path, avoiding ArcGISPro.exe"""
    # 1. Try from sys.exec_prefix (standard for ArcGIS Pro environments)
    python_exe = os.path.join(sys.exec_prefix, 'python.exe')
    if os.path.exists(python_exe): return python_exe
    
    # 2. Try from sys.prefix as fallback
    python_exe = os.path.join(sys.prefix, 'python.exe')
    if os.path.exists(python_exe): return python_exe

    # 3. Check if sys.executable IS python.exe (outside ArcGIS Pro UI)
    if sys.executable.lower().endswith('python.exe'):
        return sys.executable
        
    # 4. Final attempt: Check common relative locations from sys.executable
    # sys.executable is usually ...\bin\ArcGISPro.exe
    pro_bin = os.path.dirname(sys.executable)
    # Standard location: bin\Python\envs\arcgispro-py3\python.exe
    alt_py = os.path.join(pro_bin, 'Python', 'envs', 'arcgispro-py3', 'python.exe')
    if os.path.exists(alt_py): return alt_py
        
    return python_exe # Return best guess (last prefix + python.exe)

def get_hide_window_kwargs():
    """Get arguments to hide subprocess window"""
    kwargs = {}
    if platform.system() == 'Windows':
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = subprocess.SW_HIDE
        kwargs['startupinfo'] = startupinfo
        kwargs['creationflags'] = 0x08000000 # CREATE_NO_WINDOW
    return kwargs

class Toolbox(object):
    def __init__(self):
        """Define the toolbox (the name of the toolbox is the name of the
        .pyt file)."""
        self.label = "Deep Learning Land Cover Toolbox"
        self.alias = "DLLandCover"
        self.description = "Toolbox for Land Cover Classification using Deep Learning"

        # List of tool classes associated with this toolbox
        self.tools = [CheckLicenseStatus, InstallLibraries, ManageLandsat8, ClassifyLandCover]

# ===================================================================================
#  SUPABASE LICENSE GUARD & AUTO-UPDATE SYSTEM
# ===================================================================================
CURRENT_VERSION = "2.1.0"

class UpdateManager:
    @staticmethod
    def is_new_version(remote, current):
        try:
            r_parts = [int(x) for x in remote.split('.')]
            c_parts = [int(x) for x in current.split('.')]
            return r_parts > c_parts
        except: return remote != current

    @staticmethod
    def generate_popup_script(title, message, type='info', data=None):
        try:
            py_exe = get_python_exe()
            
            script_header = """
import tkinter as tk
import sys
import base64
from io import BytesIO

def show():
    try:
        root = tk.Tk()
        root.withdraw()
        
        COLOR_PRIMARY = '#10B981'
        COLOR_HOVER   = '#059669'
        COLOR_BG      = '#F9FAFB'
        COLOR_CARD    = '#FFFFFF'
        COLOR_TEXT    = '#1F2937'
        COLOR_SUBTEXT = '#6B7280'

        dialog = tk.Toplevel(root)
        dialog.title('Deep Learning Tools Notification')
        dialog.overrideredirect(True)
        dialog.overrideredirect(False)
        
        w = 420
        h = 520
        if TYPE == 'update': h = 420
        if TYPE == 'license_expired': h = 550
        
        sw = root.winfo_screenwidth()
        sh = root.winfo_screenheight()
        x = (sw - w) // 2
        y = (sh - h) // 2
        dialog.geometry(f'{w}x{h}+{x}+{y}')
        dialog.resizable(False, False)
        dialog.configure(bg=COLOR_BG)
        
        dialog.lift()
        dialog.attributes('-topmost',True)
        dialog.after_idle(root.attributes,'-topmost',False)

        card = tk.Frame(dialog, bg=COLOR_CARD)
        card.pack(fill="both", expand=True)

        header = tk.Frame(card, bg=COLOR_PRIMARY, pady=20, padx=15)
        header.pack(fill="x", side="top")
        
        left_col = tk.Frame(header, bg=COLOR_PRIMARY)
        left_col.pack(side="left", anchor="w")

        right_col = tk.Frame(header, bg=COLOR_PRIMARY)
        right_col.pack(side="left", fill="both", expand=True, padx=(10, 0))

        LOGO_B64 = "iVBORw0KGgoAAAANSUhEUgAAAHUAAABGCAYAAADy6tu/AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAABInSURBVHhe7V0LlF1VeY6v1qK2vvpQa63YVqSCVkGQJaC10i6XrlYlSEgyd+9zzr2TySQkLm0tUAxZ2qptsWVVQSgt7cICQttFKYrggtQSKUq6eCRhZu459333PDPJZJISW/q/9a212H7v3XPOntn7OWdHjP+3X3/x8ewV84qK52iivEJ17jmp5h5iW3qKK3kCto8kQm4rqeaNiu+ZruI4Uu0ZQ9oYvX6x0uCl//6nZ/yZ5zwPNJ3s/Z8ec2+/3v5PjhEfdt/P3V57e9/+yDHyvnO+5+x/3H/8f/H3zLm0NQhF/jFgCBXoPKfJqCNtzl52l3LZ1tF7DwyhuPqbQgl+OceODZujb0a8Zf/tgE1k4Onq8rLpZ0fB3WXfs32r4FyNErDfz96Z3v+1E4k7AXqAazvJvqei9qG2UOe3++4dFvZ7w/XoWXu6DZ1jd9CudpPrO1UzY5zq3MMtbr9mV5xpbwz3O0Xk2Z/4c4+R4a7xPx+OfuJ3/G6P8dv+f23HkG+/7R3ddt3JKP1QO1n1Z11lPxP6MPgX7Y3+D2O1C/y8ogB/4DiF18lN95+l1W18pxjyFm3/9+8F4QOXtGqGLghZ3t9J4v/ZJ/hv/8Vf9j76d9uy9q7Kev7t2/c+F//v5d/+Yj/92zcY/+3/ZL+/e7t39s31f9z3/y/+Xv7tL/59v2P4P/oFQQe07/tk2vG77+qf3r71ob/8ez/+f9Hff88x/tv/8df/3eLv/9G/f8LfC78h2LD7c36wN+8Zv/8N/b8F8oJ5/d6H1Qddy+3K8//X/xXf7dNfEFzw9/PQ5/3fu3j+/5///Y/+fd/wDP/vYc//3/fc+733//n3/Z/O/87I8/++95/3+yG/f4r+7b/4+3/k+37fP/5X//9//ff/97z//+jX/9v3f9+w/P9Hv/7fvv/fd/0/+7o/e8z/9j/+i7/s/0f8fvHn3n95v/u/z//+U9/8f6f84L///xPZ8O2/VNnwjfE4NnzPL2TDt/+SbPj29+T8/9Hf/6/+nqHv6+yf3d/eM+S8x/3Ht32n+O9w+8/yP/N/z/Gd4n+j7fjO8e3j8dx/AQAQNMgCAC7h6EQe8Pc/NB67vzFev8M/lN/3v/2n+/5X+93t+7Vd8rP73xP6f3f/Lf/2c//2h3/7nV8oV7n/N/lf/fef/8FzWc6+/YVyo7a/UP6Hd/6n/m3f0PP/9wvlFcq/+IXyd/h7+Yd/4d/v2/7Cvd77sM+3v1A+8k72/xX57UQp8H36jv7dv/7H/h62nyE/+7/lv/X/Fv/9/36hXK49/7q/5V95f+XP73+hfE97L36hXPHMf/bfd/5COf/9L/4l/3z33+r+tq69+u9/feffDv/7b/9//rV/t/j7jf0d9zv3d3//8fvn/8V/879/1t//7BfKX/zLz/+Lf/3D6/vb93/nf/X9u/+2+9uf/J7f+4v/6m/9Pf/jv7/4X/93v/jl7e/d6t7/c1f/a/fb/37xr/lH/vhLfv3c0e/5+72/6/d+5/J7f+9/X6Xy+Hn/3t94vN/7+07xe3/vMf3e33/K3/v7j/v3nZ3i6PcYv/f3k+L3/v5S/N7fd/p7f98Jfe/vI8PvO/2/7/cYv/f3//n3/L7f//99p/i9vz/y/w/5a//f5/z93u9/wu/9/ajz9/3e32983+/9fcfx/b7f7/395Pb7fv/f9/tP8Xt/f6l+7+8v7e/7/b/v95P+9/3+n+/7/ef8v/8H//z/t+//7/v9pP99v/+X9/f9/j/d9/tP/Xt///99v78s//f9/l/+3/f7z/L//3p/v/l9v7+0//f9flL9vt/f3n7f7y/17/v9/ff3/f7y/N/3+/9/f7+5f7/fX6rf9/tP+X+/3//P9/tJ9ft+///5fj/5ft/v/+fv95vm/5ff7//3/X6y/t/3+//f3++/v7/fn9/f77+7v9/v3//3/X7S/N/3+0/z+3n/n/w/7/eX/v9+v/+3+/39/v9+v/n/v9/vL9/v5/2/v5/3+0v/f7/f/x/r/wnn/X/e7z/D//1+v//v9/v98/2+n/8P/P3+8v5+3u/v5/3+Mvzf7/f/f9/vz+8n7//3/f7z/73v9//ff/v/ANV2v2sAAAAASUVORK5CYII="
        FAVICON_B64 = "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAF9UlEQVR4AZRXaWxUVRT+zhu6AAWMggtJLV0QI0RlE0SMS1FRVHBhSYQ404ZqDBCJMfoD0hpNMFEJiQGFUKYGEpAaBKMJKEJS1OCWIJgItDMVCETABVtohZZ3/O478+a9NzMt5eXs59w7527n3rFwFZ9qnaWJ6ApNxDqJmoFHtaV61lV054T2OQHVmjwkjn0FyOsAComZMBJib2NSKzMdvel9TgDJrj0QPNhbZ/QJcakmopvJ+wR9SkATsQ/Z21RiEFoA/YJJfUbjWWIAZB7brAoYehSvmIAmq55k6xpiAHQLykpGSXnD41IWn4l+haMAOYjwt0RbotPDpmyt1wS0+bnBUN3GZmZqyRzYh58vzBepsx2NREo++Af57ZMh8htVD4T653rmpSLPkIv3mIDZ8YgUmFFFAg3b0CUzZE7j5YDNEaW4sRN5YpapwzG4JIL2jv1aV9fj7/ToQGtyAkdf4vaTomrdI7duaE9pWUyK6/9Gt0wJO2Q0oscnhW2+ljMBbY0WQiPf+WGUbF0lFfW/UuoVZNSGXxhglo0sBd3a5PSZUoMsZwJQeZZBwakHrPw62voGNl4MBQr6wbaeCdlSSlYCTqaKtSm/yxRRKV/3L/r4ycg4j6W8EQ7Xej1cNShs47gyDVCLRwoDQvYBeY0hPYeiZ6sGaXNsWNrVWfhuWnaFAhToY67o06wZgNp3++6UdOTopZSUxTRRM0QTVVvRpn9CcFIT0fdMkIxZc558BdEHxWpnhn0LshOASMDviiWlL+vW2RFXcampEfxh7otuUxFn05oPQR4g1fA+u8gsg39kFdfhcviUZCdg201e+zRXvINxRcf5g7uJn2oitg+R/FMsxbWADk3HuUJ6tmTk+xehaHLNHpVXPcnw7AQqOg5zJLuMM4SC4fyxSqK5cqey44Ehv6uYH3/NFVO0W+ZTSldNiE7XZHW6vmQlIMIqV5j3NBt9Quw7iLYyqUelPB4PNmLh4kyBpyJgte1HPC2dgB6L3aat1fP0SM1QGb6ugx1xXfV2droeqme8Bjm5YD/+uDBaKuJ7cvoVtSG74AVPdxLgzrwGXezEtjcjr+tHz8nb7hA7XSgVDTdw6uYA+jUU3Z4/zRUTMWzQE2k9Q2Afa9nOnArPM05PVFcYxUmAVWoG190tEoobjSMTpayhkQlNgxUZT983RCV6EIGlmzQZfcgzZHELPC0B60W70miWIVDblF5HJDlN7BGkbP1BLk+9nI1FTPpCIDCPo9zBd+GYgM0XBW/7iiM9ZajlvPVE0puCxkPEKwJnYw0TMKNo94OlP8Terc2LC3ybK0lp/GNA/GUQVOqJ2f0tJLomAuhPdMGyVrtCmJpCpMmqO/jKieqpGufss9PvATHvRHP8kPq4X85vTckZTI8HDP3QPXCSBZHJAWOblNbvDOi+OL5oL1QPMD6Ozq6z+nvVA8Yp5Rt+Io8SfRA8rBqunCknX9UpybBuTLG4luYVY1SDwSeV0YN4V1DBZeVUV491bGXxLeS7iR6UIlm03VPSPNIdvmUtuZ8JYBzSn+YcPevDSoZkrqsFy95uloa3h8LW5YwJwrSgYmQZsdEM8D8jp/BOizv3ppQCTm/uF49t+xeM4gRn7RYuRwOAmzF+4DJyoGLED7SbN6SjkhRyz3xEngZnwwORtAG41oLAr9MqCwNOR9RkNSsiBjuKQ3QJT0Bzi1MMlpqr+3lViPtKtl5xQjyi9gJtjTknzMQg0WX2AG9ML4AViKIpKmQE0UpNxt6k5IC2xKZA7U2OYojgL5zL/9KIBqW0YT8i/SqRXFBsdHS2N0FgptlRATHD28k+TyIRa4PgPsS/g2YJamlTIqCcHsUyXrdniKfZ4Fva84kuRKy5MmFdh6u4VEasb5Xyjc7xkjGNl6A61/UEqPImFRQFLK5oYbnFOs3Xry5yLWk6hNL1RB8UbyFevNc35Ja4PIdgYRbMcEh6BlnKOrLLMgFstAa2zKScIGaAXuJMLEZ5Sa3U+f+GMoJCKjveAZGxnNE9IYdRlEsUQSXrxyqj/g8AAP//x9hkiAAAAAZJREFUAwCn6gM8xukw4AAAAABJRU5ErkJggg=="

        try:
            fav_data = base64.b64decode(FAVICON_B64)
            icon_img = tk.PhotoImage(data=fav_data)
            dialog.iconphoto(False, icon_img)
        except: pass

        try:
            img_data = base64.b64decode(LOGO_B64)
            logo_img = tk.PhotoImage(data=img_data)
            logo_lbl = tk.Label(left_col, image=logo_img, bg=COLOR_PRIMARY)
            logo_lbl.image = logo_img
            logo_lbl.pack(anchor="w")
        except: pass
        
        lbl_title = tk.Label(right_col, text="TITLE_PLACEHOLDER", font=("Segoe UI", 18, "bold"), bg=COLOR_PRIMARY, fg="white", wraplength=250, justify="center")
        lbl_title.pack(anchor="center", pady=(5, 0))
        
        lbl_msg = tk.Label(right_col, text="MESSAGE_PLACEHOLDER", font=("Segoe UI", 11), bg=COLOR_PRIMARY, fg="#ECFDF5", wraplength=250, justify="center")
        lbl_msg.pack(anchor="center", pady=(0, 5))

        content_frame = tk.Frame(card, bg=COLOR_CARD)
        content_frame.pack(fill="both", expand=False, padx=20, pady=20)
"""
            
            script_body = ""
            
            if type in ['license', 'license_expired']:
                if data:
                    app_name = data.get('app_name', 'deep_learning_tools')
                    status = data.get('status', 'Unknown')
                    tier = data.get('tier', 'Unknown')
                    expiry = data.get('expiry_date', 'N/A')
                    days_left = data.get('days_left', 'N/A')
                    machine_id = data.get('machine_id', 'N/A')
                    admin_contact = "Ardi Abu Ridho (+62 822-5476-0769)"

                    status_upper = status.upper()
                    tier_upper = tier.upper()
                    
                    if status == 'expired':
                        status_color = '#EF4444'
                        bg_color = '#FEF2F2'
                    else:
                        status_color = '#10B981'
                        bg_color = '#F0FDF4'
                        
                    script_body = f"""
        info_frame = tk.Frame(content_frame, bg='{{bg_color}}')
        info_frame.pack(pady=10, fill='x', ipadx=10, ipady=10)
        tk.Label(info_frame, text='STATUS LISENSI (DEEP LEARNING)', font=('Segoe UI', 11, 'bold'), bg='{{bg_color}}', fg='{{status_color}}').pack(pady=(0,8))
        
        info_grid = tk.Frame(info_frame, bg='{{bg_color}}')
        info_grid.pack()
        
        tk.Label(info_grid, text='Aplikasi :', font=('Segoe UI', 10, 'bold'), bg='{{bg_color}}', fg=COLOR_TEXT).grid(row=0, column=0, sticky='e', padx=5, pady=2)
        tk.Label(info_grid, text='{{app_name}}', font=('Segoe UI', 10), bg='{{bg_color}}', fg=COLOR_TEXT).grid(row=0, column=1, sticky='w', pady=2)
        
        tk.Label(info_grid, text='ID Mesin :', font=('Segoe UI', 10, 'bold'), bg='{{bg_color}}', fg=COLOR_TEXT).grid(row=1, column=0, sticky='e', padx=5, pady=2)
        tk.Label(info_grid, text='{{machine_id}}', font=('Segoe UI', 10), bg='{{bg_color}}', fg=COLOR_TEXT).grid(row=1, column=1, sticky='w', pady=2)
        
        tk.Label(info_grid, text='Status :', font=('Segoe UI', 10, 'bold'), bg='{{bg_color}}', fg=COLOR_TEXT).grid(row=2, column=0, sticky='e', padx=5, pady=2)
        tk.Label(info_grid, text='{{status_upper}}', font=('Segoe UI', 10, 'bold'), bg='{{bg_color}}', fg='{{status_color}}').grid(row=2, column=1, sticky='w', pady=2)
        
        tk.Label(info_grid, text='Tipe Paket :', font=('Segoe UI', 10, 'bold'), bg='{{bg_color}}', fg=COLOR_TEXT).grid(row=3, column=0, sticky='e', padx=5, pady=2)
        tk.Label(info_grid, text='{{tier_upper}}', font=('Segoe UI', 10), bg='{{bg_color}}', fg=COLOR_TEXT).grid(row=3, column=1, sticky='w', pady=2)
        
        tk.Label(info_grid, text='Masa Aktif :', font=('Segoe UI', 10, 'bold'), bg='{{bg_color}}', fg=COLOR_TEXT).grid(row=4, column=0, sticky='e', padx=5, pady=2)
        expiry_display = '{{expiry}}' if '{{expiry}}' == 'Lifetime' else '{{expiry}} (Sisa {{days_left}} hari)'
        tk.Label(info_grid, text=expiry_display, font=('Segoe UI', 10), bg='{{bg_color}}', fg=COLOR_TEXT).grid(row=4, column=1, sticky='w', pady=2)

        tk.Label(info_grid, text='Versi :', font=('Segoe UI', 10, 'bold'), bg='{{bg_color}}', fg=COLOR_TEXT).grid(row=5, column=0, sticky='e', padx=5, pady=2)
        tk.Label(info_grid, text='{{version}}', font=('Segoe UI', 10), bg='{{bg_color}}', fg=COLOR_TEXT).grid(row=5, column=1, sticky='w', pady=2)
        
        tk.Label(content_frame, text='Hubungi Admin jika ada kendala:', font=('Segoe UI', 9), bg=COLOR_CARD, fg=COLOR_SUBTEXT).pack(pady=(15,2))
        tk.Label(content_frame, text='{{admin_contact}}', font=('Segoe UI', 10, 'bold'), bg=COLOR_CARD, fg='#0EA5E9').pack()
""".format(app_name=app_name, machine_id=machine_id, status_upper=status_upper, status_color=status_color, 
            tier_upper=tier_upper, expiry=expiry, days_left=days_left, bg_color=bg_color, admin_contact=admin_contact, version=CURRENT_VERSION)

            script_footer = """
        footer = tk.Frame(dialog, bg='#F3F4F6', pady=15, padx=20)
        footer.pack(fill='x', side='bottom')
        
        def on_ok():
            dialog.destroy()
            root.destroy()
            sys.exit(0)
            
        tk.Button(footer, text='OK', command=on_ok, bg=COLOR_PRIMARY, fg='white', font=('Segoe UI', 12, 'bold'), relief='flat', width=12).pack(side='right')
        root.mainloop()
    except: sys.exit(1)

if __name__ == "__main__": show()
"""
            
            type_def = f"TYPE = '{type}'\n"
            final_script = type_def + script_header.replace("TITLE_PLACEHOLDER", title).replace("MESSAGE_PLACEHOLDER", message) + script_body + script_footer
            
            script_path = os.path.join(tempfile.gettempdir(), f"dl_popup_{random.randint(100,999)}.py")
            with open(script_path, "w") as f: f.write(final_script)
            
            subprocess.Popen([py_exe, script_path], **get_hide_window_kwargs())
            time.sleep(1)
            try: os.remove(script_path)
            except: pass
            return True
        except: return False

class SupabaseGuard:
    SUPABASE_URL = "https://mbfzmvlivyuajmxrecne.supabase.co"
    SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1iZnptdmxpdnl1YWpteHJlY25lIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjU0NzgwODQsImV4cCI6MjA4MTA1NDA4NH0.sZltNY30ww2Hb_oopiVDcvXnZRehWRvK2jZZU5MO64s"
    TABLE_NAME = "licenses"
    ADMIN_CONTACT = "Ardi Abu Ridho (+62 822-5476-0769)"
    
    @staticmethod
    def get_machine_id():
        try:
            # Try Windows UUID
            cmd = 'wmic csproduct get uuid'
            res = subprocess.check_output(cmd, shell=True, **get_hide_window_kwargs()).decode()
            uid = res.split('\n')[1].strip()
            if uid: return uid.replace('-', '')[:12]
        except: pass
        return hex(uuid.getnode())[2:].upper()

    @staticmethod
    def make_request(url, method="GET", data=None):
        headers = {
            "apikey": SupabaseGuard.SUPABASE_KEY,
            "Authorization": f"Bearer {SupabaseGuard.SUPABASE_KEY}",
            "Content-Type": "application/json",
            "Prefer": "return=representation"
        }
        try:
            req_data = json.dumps(data).encode('utf-8') if data else None
            req = urllib.request.Request(url, data=req_data, headers=headers, method=method)
            with urllib.request.urlopen(req, timeout=10) as response:
                if response.status in [200, 201, 204]:
                    return json.loads(response.read().decode()) or []
        except: return None

    @staticmethod
    def check_license(app_name="deep_learning_landcover"):
        mid = SupabaseGuard.get_machine_id()
        base_url = f"{SupabaseGuard.SUPABASE_URL}/rest/v1/{SupabaseGuard.TABLE_NAME}"
        
        # 1. Check Existing
        query = urllib.parse.urlencode({"machine_id": f"eq.{mid}", "app_name": f"eq.{app_name}"})
        data = SupabaseGuard.make_request(f"{base_url}?{query}", "GET")
        
        # 2. Register New (Auto Trial)
        if not data:
            payload = {
                "machine_id": mid,
                "app_name": app_name,
                "last_check": datetime.now(timezone.utc).isoformat(),
                "tier": "pro",
                "client_name": f"{platform.node()} ({getpass.getuser()})",
                "version": CURRENT_VERSION
            }
            
            data = SupabaseGuard.make_request(base_url, "POST", payload)
            if not data: return False, "Gagal registrasi trial server.", {}
        else:
            # 2. Update Existing (Tracking Last Check)
            try:
                mid_query = f"eq.{mid}"
                app_query = f"eq.{app_name}"
                patch_url = f"{base_url}?machine_id={mid_query}&app_name={app_query}"
                
                update_payload = {
                    "last_check": datetime.now(timezone.utc).isoformat(),
                    "version": CURRENT_VERSION,
                    "client_name": f"{platform.node()} ({getpass.getuser()})"
                }
                SupabaseGuard.make_request(patch_url, "PATCH", update_payload)
            except: pass # Non-fatal if update fails
        
        rec = data[0]
        status = rec.get('status', 'trial').lower()
        expiry = rec.get('expiry_date')
        
        # 3. Check Expiry
        days_left = 999
        if expiry and expiry != 'Lifetime':
            try:
                exp_date = datetime.strptime(expiry, "%Y-%m-%d")
                days_left = (exp_date - datetime.now()).days
                if days_left < 0: status = 'expired'
            except: pass
        
        info = {**rec, 'days_left': days_left}
        
        if status in ['banned', 'expired'] and rec.get('tier') != 'free':
            msg = f"[ERROR] Lisensi {status.upper()}. Hubungi {SupabaseGuard.ADMIN_CONTACT}"
            UpdateManager.generate_popup_script("Akses Ditolak", msg, data=info)
            return False, msg, info
            
        return True, "Valid", info

# ===================================================================================
#  HELPER FUNCTION: PRINT LICENSE HEADER
# ===================================================================================
def print_license_header(messages, info=None):
    try:
        if not info:
            # Check license silently if info not provided
            valid, msg, info = SupabaseGuard.check_license()
        
        status = info.get('status', 'Unknown').upper()
        tier = info.get('tier', 'Unknown')
        # Capitalize only first letter of tier for better look (e.g. Free, Pro) if preferred, or upper
        # User example showed Mixed case for some? No, "FREE" and "ACTIVE". Let's stick to UPPER or Title or match exactly.
        # User example: Tipe Paket : FREE (or Pro), Status: ACTIVE
        
        tier = tier.upper() if tier else 'UNKNOWN'
        
        expiry = info.get('expiry_date', 'Lifetime')
        app_name = info.get('app_name', 'deep_learning_landcover')
        
        messages.addMessage("")
        messages.addMessage("=" * 60)
        messages.addMessage(" STATUS LISENSI (AHZA TOOLS)")
        messages.addMessage("=" * 60)
        messages.addMessage(f" Aplikasi     : {app_name}")
        messages.addMessage(f" Status       : {status}")
        messages.addMessage(f" Tipe Paket   : {tier}")
        messages.addMessage(f" Masa Aktif   : {expiry}")
        messages.addMessage(f" Versi        : {CURRENT_VERSION}")
        messages.addMessage("")
        messages.addMessage(" Hubungi Admin jika ada kendala:")
        messages.addMessage(f" {SupabaseGuard.ADMIN_CONTACT}")
        messages.addMessage("=" * 60)
        messages.addMessage("")
    except Exception as e:
        # If license header fails, show error but don't block execution
        messages.addWarningMessage(f"[WARN] License header display failed: {str(e)}")
        pass # Don't break tool if license print fails

class CheckLicenseStatus(object):
    def __init__(self):
        self.label = "01. Cek Status Lisensi (Check License Status)"
        self.category = "00. System & Licensing"
        self.canRunInBackground = False
    def getParameterInfo(self):
        # Info Parameter (Display Only)
        param0 = arcpy.Parameter(
            displayName="[INFO] Petunjuk Penggunaan",
            name="info_display",
            datatype="GPString",
            parameterType="Optional",
            direction="Input")
        param0.value = "Klik tombol RUN di bawah untuk memulai pemeriksaan lisensi"
        return [param0]

    def execute(self, parameters, messages):
        # Tool Header
        messages.addMessage("")
        messages.addMessage("=" * 60)
        messages.addMessage(f"DEEP LEARNING LAND COVER TOOLBOX v{CURRENT_VERSION}")
        messages.addMessage("=" * 60)
        messages.addMessage("PEMERIKSAAN STATUS LISENSI")
        messages.addMessage("=" * 60)
        
        # Check license
        valid, msg, info = SupabaseGuard.check_license()
        
        # Display license status with box
        print_license_header(messages, info)
        
        # Trial period info
        status = info.get('status', 'Unknown').upper()
        expiry = info.get('expiry_date', 'Lifetime')
        
        if status == 'TRIAL':
            try:
                # Calculate remaining days
                if expiry != 'Lifetime':
                    exp_date = datetime.fromisoformat(expiry.replace('Z', '+00:00'))
                    now = datetime.now(timezone.utc)
                    delta = (exp_date - now).days
                    messages.addMessage(f"INFO: Trial period remaining: {delta} days.")
                    messages.addMessage("")
            except: pass
        
        messages.addMessage("=" * 60)
        messages.addMessage("[OK] Selesai memeriksa lisensi.")
        messages.addMessage("=" * 60)
        
        # Determine Popup Type
        popup_type = 'license'
        if status == 'EXPIRED': popup_type = 'license_expired'
        
        UpdateManager.generate_popup_script("Info Lisensi", "Detail status lisensi Anda", type=popup_type, data=info)

class InstallLibraries(object):
    def __init__(self):
        """Define the tool (tool name is the name of the class)."""
        self.label = "02. Install Deep Learning Libraries (Otomatis)"
        self.category = "00. System & Licensing"
        self.description = """Otomatis mendeteksi dan memperbaiki Deep Learning Libraries.
        Tool ini akan:
        1. Mendeteksi environment Python yang aktif
        2. Memperbaiki dependencies yang rusak/missing
        3. Menginstal PyTorch, fastai, dan dependencies lainnya
        4. Memperbaiki environment yang bermasalah"""
        self.canRunInBackground = False

    def getParameterInfo(self):
        """Define parameter definitions"""
        
        # Param 0: Repair Mode
        param0 = arcpy.Parameter(
            displayName="Mode Perbaikan",
            name="repair_mode",
            datatype="GPString",
            parameterType="Required",
            direction="Input"
        )
        param0.filter.type = "ValueList"
        param0.filter.list = ["Auto Detect & Fix", "Force Reinstall All", "Check Only"]
        param0.value = "Auto Detect & Fix"
        
        # Param 1: Use GPU
        param1 = arcpy.Parameter(
            displayName="Gunakan GPU (CUDA)",
            name="use_gpu",
            datatype="GPBoolean",
            parameterType="Optional",
            direction="Input"
        )
        param1.value = True
        
        # Param 2: Download Folder
        param2 = arcpy.Parameter(
            displayName="Folder Download",
            name="download_folder",
            datatype="DEFolder",
            parameterType="Optional",
            direction="Input"
        )
        # Default ke folder Downloads user
        default_dir = os.path.join(os.environ.get('USERPROFILE', 'C:\\'), 'Downloads')
        if os.path.exists(default_dir):
            param2.value = default_dir
        
        return [param0, param1, param2]

    def isLicensed(self):
        return True

    def updateParameters(self, parameters):
        return

    def updateMessages(self, parameters):
        return

    def execute(self, parameters, messages):
        """Execute the tool"""
        repair_mode = parameters[0].valueAsText
        use_gpu = parameters[1].value
        download_folder = parameters[2].valueAsText
        
        # Check License
        SupabaseGuard.check_license()
        
        # 1. Start Tool Header
        messages.addMessage("")
        messages.addMessage("=" * 60)
        messages.addMessage(f"DEEP LEARNING LIBRARIES INSTALLER & FIXER (v{CURRENT_VERSION})")
        messages.addMessage("=" * 60)
        
        # Display License Header
        print_license_header(messages)
        
        # ====================================================================
        # 1. DIAGNOSIS SISTEM
        # ====================================================================
        messages.addMessage("\n[1] DIAGNOSIS SISTEM...")
        
        # CLEANUP: Detect and fix common environment conflicts
        self.clean_user_site_conflicts(messages)
        
        # Get system info
        sys_info = self.get_system_info()
        for key, value in sys_info.items():
            messages.addMessage(f"  {key}: {value}")
        
        # Check Python environment
        env_info = self.check_python_environment()
        messages.addMessage(f"\n  Environment: {env_info['env_name']}")
        messages.addMessage(f"  Python: {env_info['python_version']}")
        messages.addMessage(f"  ArcGIS Pro: {env_info['arcgis_version']}")
        messages.addMessage(f"  Path: {env_info['env_path']}")
        
        # Check for incompatible environment
        if env_info['is_problematic']:
            messages.addWarningMessage(f"  [!] Environment bermasalah: {env_info['issue']}")
        
        # ====================================================================
        # 2. DETEKSI HARDWARE
        # ====================================================================
        messages.addMessage("\n[2] DETEKSI HARDWARE")
        messages.addMessage("-" * 60)
        
        # Deteksi GPU di awal (sebelum cek dependensi)
        gpu_info = self.detect_gpu_capability()
        
        # Tampilkan info hardware yang terdeteksi
        if gpu_info['has_nvidia_gpu']:
            messages.addMessage(f"  • GPU: {gpu_info['gpu_name']}")
            if gpu_info['driver_installed']:
                messages.addMessage(f"  • Driver NVIDIA: Terinstal")
            if gpu_info['cuda_available']:
                ver_str = f" (v{gpu_info['cuda_version']})" if gpu_info.get('cuda_version') else ""
                messages.addMessage(f"  • CUDA: Tersedia{ver_str}")
                messages.addMessage(f"  • Strategi: Install PyTorch GPU (akselerasi CUDA)")
            else:
                messages.addMessage(f"  • CUDA: Belum terinstal")
                messages.addMessage(f"  • Strategi: Install PyTorch CPU (bisa upgrade nanti)")
        else:
            messages.addMessage(f"  • GPU NVIDIA: Tidak terdeteksi")
            messages.addMessage(f"  • Strategi: Install PyTorch CPU")
        
        # ====================================================================
        # 3. PERIKSA DEPENDENSI DEEP LEARNING
        # ====================================================================
        messages.addMessage("\n[3] MEMERIKSA DEPENDENSI...")
        
        deps_status = self.check_dependencies()
        missing_deps = []
        for dep, status in deps_status.items():
            if status['installed']:
                messages.addMessage(f"  • {dep}: {status['version']}")
            else:
                messages.addMessage(f"  • {dep}: MISSING")
                missing_deps.append(dep)
        
        # ====================================================================
        # 4. DECIDE ACTION BASED ON MODE
        # ====================================================================
        if repair_mode == "Check Only":
            messages.addMessage("\n[4] CHECK ONLY MODE - Tidak melakukan instalasi")
            messages.addMessage(f"   Total dependencies: {len(deps_status)}")
            messages.addMessage(f"   Terinstal: {len(deps_status) - len(missing_deps)}")
            messages.addMessage(f"   Missing: {len(missing_deps)}")
            if missing_deps:
                messages.addWarningMessage(f"   Dependencies missing: {', '.join(missing_deps)}")
            return
        
        # ====================================================================
        # 5. PERBAIKI MASALAH LINGKUNGAN
        # ====================================================================
        messages.addMessage("\n[5] MEMPERBAIKI MASALAH LINGKUNGAN...")
        
        # Fix 1: Check if running in correct environment
        if env_info['is_problematic']:
            fix_result = self.fix_environment_issue(env_info, messages)
            if not fix_result:
                messages.addErrorMessage("Gagal memperbaiki environment. Silakan switch ke 'arcgispro-py3' manual.")
                return
        
        # Fix 2: Repair pip
        messages.addMessage("  Memperbaiki pip...")
        self.repair_pip()
        
        # Fix 3: Upgrade setuptools and wheel
        messages.addMessage("  Memperbarui setuptools dan wheel...")
        self.upgrade_build_tools()
        
        # ====================================================================
        # 6. INSTAL/PERBAIKI DEPENDENSI
        # ====================================================================
        messages.addMessage("\n[6] MENGINSTAL DEPENDENSI...")
        messages.addMessage("-" * 60)
        
        # Tentukan versi PyTorch berdasarkan pilihan user + validasi hardware
        cuda_version = "cpu"  # Default
        
        if use_gpu:
            # User minta GPU, tapi kita validasi dulu
            if gpu_info['has_nvidia_gpu'] and gpu_info['cuda_available']:
                # GPU ada, CUDA ada. Install GPU version
                messages.addMessage("\n[KEPUTUSAN]")
                
                # Cek jika CUDA 12.x terdeteksi
                if gpu_info.get('cuda_version') and gpu_info['cuda_version'].startswith('12'):
                    messages.addMessage("  • Menginstal PyTorch (GPU version) untuk CUDA 12.x")
                    cuda_version = "cu121" # PyTorch stable for CUDA 12.1 usually works for 12.0
                else:
                    messages.addMessage("  • Menginstal PyTorch (GPU version) dengan CUDA 11.8")
                    cuda_version = "cu118"
                
                messages.addMessage("  • Klasifikasi akan menggunakan akselerasi GPU")
            elif gpu_info['has_nvidia_gpu'] and not gpu_info['cuda_available']:
                # GPU ada, tapi CUDA belum install
                messages.addWarningMessage("\n[PERINGATAN]")
                messages.addWarningMessage("  • GPU terdeteksi, tapi CUDA Toolkit belum terinstal!")
                
                # Tawarkan auto-download CUDA installer
                try:
                    import ctypes
                    mbox_style = 4 | 0x40 | 0x1000  # Yes/No + Info Icon + System Modal
                    result = ctypes.windll.user32.MessageBoxW(
                        0,
                        f"GPU Terdeteksi: {gpu_info['gpu_name']}\n\n"
                        "CUDA Toolkit belum terinstal.\n"
                        "CUDA diperlukan untuk akselerasi GPU.\n\n"
                        "Apakah Anda ingin mendownload CUDA Toolkit sekarang?\n"
                        "(Ukuran: ~3GB, butuh koneksi internet)\n\n"
                        "Klik 'Yes' untuk download otomatis\n"
                        "Klik 'No' untuk install PyTorch CPU dulu",
                        "CUDA Toolkit Required",
                        mbox_style
                    )
                    
                    if result == 6:  # User klik Yes
                        messages.addMessage("\n[AUTO-DOWNLOAD CUDA]")
                        download_success = self.download_cuda_installer(download_folder, messages)
                        
                        if download_success:
                            messages.addMessage("\n[INSTRUKSI INSTALASI CUDA]")
                            messages.addMessage("  1. CUDA installer sudah didownload ke folder Downloads")
                            messages.addMessage("  2. Installer akan dibuka otomatis")
                            messages.addMessage("  3. Ikuti wizard instalasi (klik Next-Next-Install)")
                            messages.addMessage("  4. Setelah selesai, RESTART komputer")
                            messages.addMessage("  5. Jalankan tool ini lagi dengan mode 'Force Reinstall All'")
                            messages.addMessage("\n  Untuk sementara, PyTorch CPU akan diinstal...")
                        else:
                            messages.addWarningMessage("\n[DOWNLOAD GAGAL]")
                            messages.addWarningMessage("  • Download CUDA gagal (mungkin koneksi internet bermasalah)")
                            messages.addWarningMessage("  • Silakan download manual dari:")
                            messages.addWarningMessage("    https://developer.nvidia.com/cuda-11-8-0-download-archive")
                    else:
                        # User klik No
                        messages.addMessage("\n[INFO]")
                        messages.addMessage("  • Anda memilih untuk tidak download CUDA sekarang")
                        messages.addMessage("  • PyTorch CPU akan diinstal")
                        messages.addMessage("\n[TIPS UPGRADE KE GPU NANTI]")
                        messages.addMessage("  1. Download CUDA Toolkit 11.8:")
                        messages.addMessage("     https://developer.nvidia.com/cuda-11-8-0-download-archive")
                        messages.addMessage("  2. Install CUDA, lalu restart komputer")
                        messages.addMessage("  3. Jalankan tool ini lagi dengan mode 'Force Reinstall All'")
                
                except Exception as e:
                    messages.addWarningMessage(f"\n[ERROR] Gagal menampilkan dialog: {str(e)}")
                    messages.addWarningMessage("  • Menginstal PyTorch CPU sebagai fallback")
                
                cuda_version = "cpu"
            else:
                # Tidak ada GPU sama sekali
                messages.addWarningMessage("\n[PERINGATAN]")
                messages.addWarningMessage("  • Anda memilih mode GPU, tapi tidak ada GPU NVIDIA yang terdeteksi")
                messages.addWarningMessage("  • Menginstal PyTorch (CPU version) sebagai fallback")
                messages.addWarningMessage("  • Klasifikasi akan berjalan di CPU (lebih lambat)")
                cuda_version = "cpu"
        else:
            # User pilih CPU mode
            messages.addMessage("\n[KEPUTUSAN]")
            messages.addMessage("  • Menginstal PyTorch (CPU version) sesuai pilihan user")
            if gpu_info['has_nvidia_gpu']:
                messages.addMessage("\n[INFO]")
                messages.addMessage("  • GPU terdeteksi, tapi Anda memilih mode CPU")
                messages.addMessage("  • Untuk performa lebih cepat, centang 'Gunakan GPU (CUDA)' dan jalankan lagi")
            cuda_version = "cpu"

        # Check for Read-Only Environment early in execution
        # Only trigger auto-clone if it's the DEFAULT arcgispro-py3 in Program Files
        # Don't trigger if it's already a cloned environment (like geo-geemap, DLP-LCL8, etc)
        is_default_env = env_info['env_name'].lower() in ['arcgispro-py3', 'pro-py3']
        is_in_program_files = "Program Files" in env_info['env_path']
        
        if is_default_env and is_in_program_files:
            messages.addWarningMessage("============================================================")
            messages.addWarningMessage("DETEKSI: Environment Anda berada di PROGRAM FILES (Read-Only).")
            messages.addWarningMessage("============================================================")
            
            # NEW: Proactively try to clone the environment
            target_env = "DLP-LCL8"
            messages.addMessage(f"\n[!] INGIN MELAKUKAN OTOMATISASI CLONE KE: {target_env}?")
            messages.addMessage("  Proses ini akan membuat salinan environment agar bisa diinstal library.")
            
            clone_success = self.clone_environment(messages, target_env)
            
            if clone_success:
                # NEW: Swap to the new environment immediately
                self.swap_environment(messages, target_env)
                
                # Get the new python executable to continue installation
                new_py_exe = self.get_env_python(target_env)
                if new_py_exe and os.path.exists(new_py_exe):
                    messages.addMessage(f"\n[!] Melanjutkan instalasi ke environment baru: {target_env}")
                    # Redirect subsequent installs to the new python
                    # We can't change sys.executable but we can pass new_py_exe to install methods
                    success_p = self.install_pytorch(cuda_version, messages, custom_py=new_py_exe, force=(repair_mode == "Force Reinstall All"))
                    success_f = self.install_fastai(messages, custom_py=new_py_exe, force=(repair_mode == "Force Reinstall All"))
                    self.install_other_dependencies(messages, custom_py=new_py_exe)
                    
                    if success_p and success_f:
                        messages.addMessage("\n" + "="*60)
                        messages.addMessage("FINALISASI PERBAIKAN (PYTHON 3.13 OPTIMIZATION)")
                        messages.addMessage("="*60)
                        # NEW: Apply the "Jalur Langit" Fix for clients
                        self.apply_shadow_dll_fix(messages)
                        
                        messages.addMessage("\n" + "="*60)
                        messages.addMessage("FINALISASI PERBAIKAN (PYTHON 3.13 OPTIMIZATION)")
                        messages.addMessage("="*60)
                        # NEW: Apply the "Jalur Langit" Fix for clients
                        self.apply_shadow_dll_fix(messages)
                        
                        messages.addMessage("\n" + "="*60)
                        messages.addMessage(" INSTALASI BERHASIL DI ENVIRONMENT BARU!")
                        messages.addMessage("="*60)
                        messages.addMessage(f" 1. RESTART ArcGIS Pro Anda sekarang.")
                        messages.addMessage(f" 2. Environment '{target_env}' sudah otomatis aktif.")
                        messages.addMessage("="*60)
                        
                        # Offer Restart
                        self.restart_arcgis_pro(messages)
                    else:
                        messages.addWarningMessage("\n[!] Instalasi selesai dengan beberapa peringatan.")
                        messages.addMessage("Mohon restart ArcGIS Pro dan jalankan kembali tool ini jika ada library yang belum terbaca.")
                else:
                    messages.addWarningMessage(f"\n[!] Berhasil kloning tapi gagal mendeteksi python di {target_env}.")
                    messages.addMessage("Silakan ganti environment manual di Settings ArcGIS Pro.")
                    
                    # Force offer restart because proswap ALREADY happened
                    self.restart_arcgis_pro(messages)
            else:
                messages.addErrorMessage("\nGagal otomatisasi clone. Silakan lakukan clone manual di Package Manager.")
            return
        
        # Install PyTorch
        if repair_mode == "Auto Detect & Fix" and \
           deps_status.get('torch', {}).get('installed') and \
           deps_status.get('torchvision', {}).get('installed'):
            messages.addMessage(f"  • PyTorch sudah terinstal (v{deps_status['torch']['version']}). Melewati...")
            torch_success = True
        else:
            messages.addMessage(f"  Menginstal PyTorch (Tipe: {cuda_version})...")
            torch_success = self.install_pytorch(cuda_version, messages)
        
        if not torch_success and repair_mode == "Force Reinstall All":
            messages.addMessage("  • Mencoba metode alternatif...")
            torch_success = self.install_pytorch_alternative(cuda_version, messages)
        
        # Install fastai
        if torch_success:
            if repair_mode == "Auto Detect & Fix" and deps_status.get('fastai', {}).get('installed'):
                messages.addMessage(f"  • fastai sudah terinstal (v{deps_status['fastai']['version']}). Melewati...")
                fastai_success = True
            else:
                messages.addMessage("  Menginstal fastai...")
                fastai_success = self.install_fastai(messages)
        else:
            messages.addWarningMessage("  [!] Melewati fastai karena PyTorch gagal")
            fastai_success = False
        
        # Install other dependencies
        other_deps = ['cryptography', 'Pillow', 'numpy', 'pandas', 'scikit-learn', 'matplotlib', 'scikit-image']
        all_others_installed = all(deps_status.get(d, {}).get('installed') for d in other_deps)
        
        if repair_mode == "Auto Detect & Fix" and all_others_installed:
            messages.addMessage("  • Dependensi lain sudah lengkap. Melewati...")
        else:
            messages.addMessage("  Menginstal dependencies lainnya...")
            self.install_other_dependencies(messages)
        
        # ====================================================================
        # 6. VERIFICATION
        # ====================================================================
        messages.addMessage("\n[5] VERIFIKASI INSTALASI...")
        
        # Re-check dependencies
        final_check = self.check_dependencies()
        all_ok = all(status['installed'] for status in final_check.values())
        
        if all_ok:
            messages.addMessage("  • SEMUA DEPENDENSI TERINSTAL DENGAN BAIK!")
        else:
            messages.addWarningMessage("  [!] Beberapa dependensi masih bermasalah:")
            for dep, status in final_check.items():
                if not status['installed']:
                    messages.addWarningMessage(f"    - {dep}")
        
        # Test imports
        messages.addMessage("\n  Testing imports...")
        test_results = self.test_imports()
        for module, success in test_results.items():
            if success:
                messages.addMessage(f"    • {module}: OK")
            else:
                messages.addErrorMessage(f"    • {module}: GAGAL")
        
        # ====================================================================
        # 7. FINAL MESSAGES
        # ====================================================================
        messages.addMessage("")
        messages.addMessage("INSTALASI SELESAI!")
        messages.addMessage("-" * 40)
        
        # Core critical check for restart
        core_libs = ['torch', 'torchvision', 'fastai']
        core_ok = all(test_results.get(lib, False) for lib in core_libs)
        
        
        if all_ok and core_ok:
            messages.addMessage("\n" + "="*60)
            messages.addMessage("? INSTALASI BERHASIL!")
            messages.addMessage("="*60)
            
            # Tampilkan info PyTorch yang terinstal
            try:
                import torch
                torch_version = torch.__version__
                if 'cpu' in torch_version.lower() or not torch.cuda.is_available():
                    messages.addMessage(f"\n? PyTorch: {torch_version} (CPU)")
                    messages.addMessage("??  Mode: CPU - Klasifikasi akan berjalan di processor")
                    
                    # Cek apakah ada GPU yang bisa diupgrade
                    gpu_check = self.detect_gpu_capability()
                    if gpu_check['has_nvidia_gpu']:
                        messages.addMessage("\n? TIPS UPGRADE KE GPU:")
                        messages.addMessage(f"   • GPU Terdeteksi: {gpu_check['gpu_name']}")
                        if not gpu_check['cuda_available']:
                            messages.addMessage("   • Install CUDA Toolkit 11.8 untuk performa 5-10x lebih cepat")
                            messages.addMessage("   • Download: https://developer.nvidia.com/cuda-11-8-0-download-archive")
                        messages.addMessage("   • Setelah install CUDA, jalankan tool ini lagi dengan:")
                        messages.addMessage("     - Centang 'Gunakan GPU (CUDA)'")
                        messages.addMessage("     - Pilih mode 'Force Reinstall All'")
                else:
                    messages.addMessage(f"\n? PyTorch: {torch_version} (GPU)")
                    messages.addMessage(f"? Mode: GPU - Klasifikasi akan menggunakan akselerasi CUDA")
                    if torch.cuda.is_available():
                        messages.addMessage(f"? GPU: {torch.cuda.get_device_name(0)}")
            except:
                pass
            
            messages.addMessage("\n? Semua library Deep Learning siap digunakan!")
            messages.addMessage("="*60)
            
            # Offer Auto-Restart
            self.restart_arcgis_pro(messages)
            
        else:
            messages.addWarningMessage("\n[!] ADA MASALAH YANG PERLU DIPERBAIKI:")
            
            # Check if environment is likely read-only (Hardcoded default only)
            if env_info['env_name'] == "arcgispro-py3" and "Program Files" in env_info['env_path']:
                messages.addErrorMessage("DETEKSI: Environment Anda berada di Program Files (Read-Only).")
                messages.addErrorMessage("SOLUSI: Silakan 'Clone' environment ini terlebih dahulu melalui ArcGIS Pro Package Manager.")
            
            messages.addWarningMessage("1. Pastikan environment yang benar ('arcgispro-py3' atau hasil clone)")
            messages.addWarningMessage("2. Jalankan tool ini lagi dengan mode 'Force Reinstall All'")
            messages.addWarningMessage("3. Atau install manual melalui Python Command Prompt:")
            
            # Fixed manual command instructions
            py_exe = get_python_exe()
            messages.addMessage("\nPerintah manual (Jalankan sebagai Administrator):")
            messages.addMessage(f'"{py_exe}" -m pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu')
            messages.addMessage(f'"{py_exe}" -m pip install fastai cryptography pillow')
        
        messages.addMessage("\nTips:")
        messages.addMessage("- Gunakan environment hasil 'Clone' untuk menghindari masalah izin akses")
        messages.addMessage("- Restart ArcGIS Pro jika mengalami masalah")
        messages.addMessage("- Pastikan GPU drivers up to date untuk performa terbaik")
        
        return

    def restart_arcgis_pro(self, messages):
        """Ask user to restart ArcGIS Pro and reopen current project"""
        try:
            import ctypes
            import subprocess
            
            # 1. Ask User
            # MessageBox types: 0=OK, 1=OK/Cancel, 4=Yes/No. Return: 6=Yes, 7=No
            mbox_style = 4 | 0x40 | 0x1000 # Yes/No + Info Icon + System Modal
            result = ctypes.windll.user32.MessageBoxW(0, 
                "Instalasi Selesai! \n\nApakah Anda ingin RESTART ArcGIS Pro sekarang untuk menerapkan perubahan?", 
                "Deep Learning Installer", mbox_style)
            
            if result != 6: # If not Yes
                messages.addMessage("\n[INFO] Restart dibatalkan pengguna. Silakan restart manual.")
                return

            # 2. Prepare Paths (Ensure Absolute & Persistent)
            try:
                install_info = arcpy.GetInstallInfo()
                install_dir = install_info.get('InstallDir', '')
                pro_exe = os.path.join(install_dir, "bin", "ArcGISPro.exe")
            except:
                pro_base = os.path.dirname(os.path.dirname(sys.executable))
                pro_exe = os.path.join(pro_base, "ArcGISPro.exe")
            
            pro_exe = os.path.abspath(pro_exe)

            # Get absolute project path
            try:
                aprx = arcpy.mp.ArcGISProject("CURRENT")
                project_path = os.path.abspath(aprx.filePath) if aprx.filePath else ""
            except:
                project_path = ""

            # 3. Create Restarter Script in Toolbox Directory (Persistent)
            current_pid = os.getpid()
            script_dir = os.path.dirname(os.path.abspath(__file__))
            batch_path = os.path.join(script_dir, f"restart_arcgis_pro.bat")
            
            # Quoted paths for Batch
            q_pro_exe = f'"{pro_exe}"'
            q_project = f'"{project_path}"' if project_path else ""
            
            batch_content = f"""@echo off
setlocal
title ================= ARCGIS PRO RESTART MANAGER =================
echo.
echo [1] Menutup ArcGIS Pro secara halus...
echo     Sistem akan mencoba memunculkan dialog SAVE...
powershell -Command "$p = Get-Process ArcGISPro -ErrorAction SilentlyContinue; if ($p) {{ $p.CloseMainWindow(); $t=45; while(!$p.HasExited -and $t -gt 0){{$t--; Write-Host 'Menunggu...' $t; Sleep 1}}; if(!$p.HasExited){{Stop-Process -Name ArcGISPro -Force}} }}"

echo.
echo [2] Melepas file lock database (Sabar sejenak)...
timeout /t 8 /nobreak >nul

echo.
echo [3] Mencoba membuka kembali:
echo     Aplikasi: {q_pro_exe}
echo     Project : {q_project}
echo.

if exist {q_project} (
    start "" {q_pro_exe} {q_project}
) else (
    echo [WARN] Project file tidak ditemukan, membuka aplikasi saja.
    start "" {q_pro_exe}
)

echo.
echo [4] SELESAI. Window ini akan menutup otomatis dalam 5 detik.
timeout /t 5 >nul
exit
"""
            with open(batch_path, "w") as f:
                f.write(batch_content)
            
            messages.addMessage("\n" + "="*60)
            messages.addMessage("  KONFIGURASI RESTART BERHASIL")
            messages.addMessage(f"  Project: {project_path if project_path else 'N/A'}")
            messages.addMessage("  [INFO] Klik SAVE jika muncul dialog.")
            messages.addMessage("  Jangan tutup jendela hitam yang muncul nanti.")
            messages.addMessage("="*60)
            
            # 4. Execute Batch (Visible Console)
            subprocess.Popen(batch_path, shell=True, creationflags=subprocess.CREATE_NEW_CONSOLE)
            
            # 5. Finish normally
            return True
        except Exception as e:
            messages.addWarningMessage(f"[!] Gagal restart otomatis: {str(e)}")
            messages.addMessage("Silakan restart ArcGIS Pro secara manual.")

    # =========================================================================
    # HELPER METHODS
    # =========================================================================
    
    def apply_shadow_dll_fix(self, messages):
        """
        [THE ULTIMATE FIX]
        Automates Shadow DLL Injection & Surgical sitecustomize.py redirection.
        Ensures Python 3.13 high performance (GPU) while bypassing cryptography DLL errors.
        """
        try:
            import site, shutil
            user_site = site.getusersitepackages()
            python_exe = get_python_exe()
            is_py313 = "3.13" in sys.version
            
            if not is_py313:
                return # Only needed for 3.13+
                
            # messages.addMessage("\n[!] Menerapkan Optimasi 'Jalur Langit' (Shadow DLL Protection)...")
            
            # 1. Install cryptography to USER Roaming
            # messages.addMessage("  • Memasang library pelindung di Roaming...")
            cmd_pip = [python_exe, "-m", "pip", "install", "cryptography==43.0.3", "--user", "--no-deps"]
            subprocess.run(cmd_pip, capture_output=True, **get_hide_window_kwargs())
            
            # 2. Locate Source DLLs from ArcGIS Pro Env
            # Source: ...\envs\DLP-LCL8\Library\bin\lib*.dll
            env_path = os.path.dirname(os.path.dirname(python_exe))
            source_dll_dir = os.path.join(env_path, "Library", "bin")
            
            # Target: Roaming\cryptography\hazmat\bindings\
            target_dll_dir = os.path.join(user_site, "cryptography", "hazmat", "bindings")
            
            if not os.path.exists(target_dll_dir):
                os.makedirs(target_dll_dir, exist_ok=True)
                
            dlls = ["libcrypto-3-x64.dll", "libssl-3-x64.dll"]
            for dll in dlls:
                src_dll = os.path.join(source_dll_dir, dll)
                dst_dll = os.path.join(target_dll_dir, dll)
                if os.path.exists(src_dll):
                    try:
                        shutil.copy2(src_dll, dst_dll)
                        # messages.addMessage(f"  • Memasang Guard: {dll}")
                    except: pass
            
            # 3. Create Surgical sitecustomize.py
            # messages.addMessage("  • Memasang Radar Cerdas (Surgical Redirector)...")
            sc_path = os.path.join(user_site, "sitecustomize.py")
            sc_content = """import sys
import os
import importlib.abc
import importlib.util

# Surgical Redirector for ArcGIS Pro 3.6+
class ArcGISShadowRedirector(importlib.abc.MetaPathFinder):
    def __init__(self):
        self.roaming_path = r"{user_site}"
        self.redirect_targets = {"cryptography", "cffi", "pycparser"}

    def find_spec(self, fullname, path, target=None):
        prefix = fullname.split('.')[0]
        if prefix in self.redirect_targets:
            target_dir = os.path.join(self.roaming_path, *fullname.split('.'))
            init_py = os.path.join(target_dir, "__init__.py")
            if os.path.exists(init_py):
                return importlib.util.spec_from_file_location(fullname, init_py, submodule_search_locations=[target_dir])
            mod_py = target_dir + ".py"
            if os.path.exists(mod_py):
                return importlib.util.spec_from_file_location(fullname, mod_py)
            for ext in [".cp313-win_amd64.pyd", ".pyd"]:
                mod_pyd = target_dir + ext
                if os.path.exists(mod_pyd):
                    return importlib.util.spec_from_file_location(fullname, mod_pyd)
        return None

if not any(isinstance(x, ArcGISShadowRedirector) for x in sys.meta_path):
    sys.meta_path.insert(0, ArcGISShadowRedirector())

shadow_dll_dir = os.path.join(r"{user_site}", "cryptography", "hazmat", "bindings")
if os.path.exists(shadow_dll_dir):
    if shadow_dll_dir not in os.environ.get("PATH", ""):
        os.environ["PATH"] = shadow_dll_dir + ";" + os.environ.get("PATH", "")
    try: os.add_dll_directory(shadow_dll_dir)
    except: pass
""".replace("{user_site}", user_site.replace("\\", "\\\\"))

            with open(sc_path, "w") as f:
                f.write(sc_content)
            
            # 4. Final Cleanup (Remove CPU Torch from Roaming if accidentally installed)
            for junk in ["torch", "torchvision", "numpy", "PIL", "pillow", "sklearn", "scikit_learn"]:
                junk_path = os.path.join(user_site, junk)
                if os.path.exists(junk_path):
                    try: shutil.rmtree(junk_path, ignore_errors=True)
                    except: pass
            
            # messages.addMessage("  [OK] Optimasi selesai & Sinkron.")
            
        except Exception as e:
            messages.addWarningMessage(f"  [!] Gagal sinkronisasi otomatis: {str(e)}")

    def get_system_info(self):
        """Get system information"""
        info = {
            "OS": platform.system() + " " + platform.release(),
            "Architecture": platform.architecture()[0],
            "Processor": platform.processor(),
            "Python Executable": sys.executable,
            "Python Path": sys.prefix
        }
        return info
    
    def check_python_environment(self):
        """Check Python environment status"""
        env_path = sys.prefix
        python_version = sys.version.split()[0]
        
        # Get ArcGIS Pro version
        try:
            version_info = arcpy.GetInstallInfo()
            arcgis_version = version_info.get('Version', 'Unknown')
        except:
            arcgis_version = 'Unknown'
        
        # Detect environment name
        env_name = "Unknown"
        is_problematic = False
        issue = ""
        
        if "geo-geemap" in env_path.lower():
            env_name = "geo-geemap"
            is_problematic = True
            issue = "Environment custom, mungkin Python 3.13 (tidak kompatibel)"
        elif "arcgispro-py3" in env_path.lower():
            env_name = "arcgispro-py3"
        elif "pro-py3" in env_path.lower():
            env_name = "arcgispro-py3"
        else:
            env_name = os.path.basename(env_path)
        
        # Check Python version compatibility
        if "3.13" in python_version:
            # Python 3.13 is new, but we must try to support it if it's the only option.
            is_problematic = False # Allow execution
            issue = "Python 3.13 terdeteksi (Experimental)"
        
        return {
            'env_name': env_name,
            'env_path': env_path,
            'python_version': python_version,
            'arcgis_version': arcgis_version,
            'is_problematic': is_problematic,
            'issue': issue
        }
    
    def download_cuda_installer(self, download_folder, messages):
        """Download CUDA Toolkit installer"""
        try:
            import urllib.request
            import os
            
            # CUDA 11.8 Direct Download Link (Windows x64)
            cuda_url = "https://developer.download.nvidia.com/compute/cuda/11.8.0/local_installers/cuda_11.8.0_522.06_windows.exe"
            cuda_filename = "cuda_11.8.0_windows.exe"
            
            # Ensure download folder exists
            if not os.path.exists(download_folder):
                os.makedirs(download_folder)
            
            output_path = os.path.join(download_folder, cuda_filename)
            
            # Check if already downloaded
            if os.path.exists(output_path):
                messages.addMessage(f"  • CUDA installer sudah ada: {output_path}")
                messages.addMessage("  • Membuka installer...")
                os.startfile(output_path)
                return True
            
            messages.addMessage(f"  • Mendownload CUDA dari NVIDIA...")
            messages.addMessage(f"  • Ukuran: ~3GB (mohon tunggu, ini bisa memakan waktu 10-30 menit)")
            messages.addMessage(f"  • Lokasi: {output_path}")
            
            # Download with progress (simplified)
            def download_progress(block_num, block_size, total_size):
                downloaded = block_num * block_size
                if total_size > 0:
                    percent = min(100, (downloaded * 100) // total_size)
                    if percent % 10 == 0:  # Report every 10%
                        messages.addMessage(f"    Progress: {percent}%")
            
            urllib.request.urlretrieve(cuda_url, output_path, reporthook=download_progress)
            
            messages.addMessage("  • Download selesai!")
            messages.addMessage("  • Membuka CUDA installer...")
            
            # Open installer
            os.startfile(output_path)
            
            return True
            
        except Exception as e:
            messages.addWarningMessage(f"  • Error saat download: {str(e)}")
            return False
    
    def check_dependencies(self):

        """Check if deep learning dependencies are installed"""
        dependencies = {
            'torch': {'pip_name': 'torch', 'min_version': '2.0.0'},
            'torchvision': {'pip_name': 'torchvision', 'min_version': '0.15.0'},
            'fastai': {'pip_name': 'fastai', 'min_version': '2.7.0'},
            'cryptography': {'pip_name': 'cryptography', 'min_version': '40.0.0'},
            'Pillow': {'pip_name': 'Pillow', 'min_version': '9.0.0'},
            'numpy': {'pip_name': 'numpy', 'min_version': '1.21.0'},
            'pandas': {'pip_name': 'pandas', 'min_version': '1.3.0'},
            'scikit-learn': {'pip_name': 'scikit-learn', 'min_version': '0.24.0'},
            'matplotlib': {'pip_name': 'matplotlib', 'min_version': '3.0.0'},
            'scikit-image': {'pip_name': 'scikit-image', 'min_version': '0.18.0'},
            'timm': {'pip_name': 'timm', 'min_version': '0.6.0'},
        }
        
        results = {}
        
        # FIX OpenMP ERROR: Force allow duplicate libraries (MKL usually valid)
        os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

        # AUTO-FIX PATH (Library Injection for Installer Verification)
        import site
        try:
            user_site = site.getusersitepackages()
            if user_site not in sys.path:
                sys.path.append(user_site)
            # Also check standard site-packages in the env
            env_site = os.path.join(sys.prefix, 'Lib', 'site-packages')
            if env_site not in sys.path:
                sys.path.append(env_site)
        except: pass
        
        for dep_name, dep_info in dependencies.items():
            try:
                # Try to import
                if dep_name == 'torch':
                    import torch
                    version = torch.__version__
                elif dep_name == 'torchvision':
                    import torchvision
                    version = torchvision.__version__
                elif dep_name == 'fastai':
                    import fastai
                    version = fastai.__version__
                elif dep_name == 'cryptography':
                    import cryptography
                    version = cryptography.__version__
                elif dep_name == 'Pillow':
                    from PIL import __version__ as pil_version
                    version = pil_version
                elif dep_name == 'numpy':
                    import numpy
                    version = numpy.__version__
                elif dep_name == 'pandas':
                    import pandas
                    version = pandas.__version__
                elif dep_name == 'scikit-learn':
                    import sklearn
                    version = sklearn.__version__
                elif dep_name == 'matplotlib':
                    import matplotlib
                    version = matplotlib.__version__
                elif dep_name == 'scikit-image':
                    import skimage
                    version = skimage.__version__
                
                results[dep_name] = {
                    'installed': True,
                    'version': version
                }
            except ImportError:
                results[dep_name] = {
                    'installed': False,
                    'version': 'Not installed'
                }
            except Exception as e:
                results[dep_name] = {
                    'installed': False,
                    'version': f'Error: {str(e)}'
                }
        
        return results
    
    def fix_environment_issue(self, env_info, messages):
        """Try to fix environment issues"""
        # We try to proceed even if flagged, unless it's critical
        return True
    
    def repair_pip(self):
        """Repair pip installation"""
        try:
            python_exe = get_python_exe()
            subprocess.run([
                python_exe, "-m", "pip", "install", "--upgrade", "pip", "--no-user",
                "--trusted-host", "pypi.org",
                "--trusted-host", "files.pythonhosted.org"
            ], check=True, capture_output=True, timeout=60, **get_hide_window_kwargs())
            return True
        except:
            return False
    
    def upgrade_build_tools(self):
        """Upgrade setuptools and wheel"""
        try:
            python_exe = get_python_exe()
            subprocess.run([
                python_exe, "-m", "pip", "install", "--upgrade",
                "setuptools", "wheel", "--no-user",
                "--trusted-host", "pypi.org",
                "--trusted-host", "files.pythonhosted.org"
            ], check=True, capture_output=True, timeout=60, **get_hide_window_kwargs())
            return True
        except:
            return False
    
    def detect_gpu_capability(self):
        """Deteksi GPU NVIDIA dan kemampuan CUDA secara menyeluruh"""
        gpu_info = {
            'has_nvidia_gpu': False,
            'gpu_name': 'Tidak terdeteksi',
            'cuda_available': False,
            'driver_installed': False,
            'cuda_version': None
        }
        
        # Method 1: Check nvidia-smi (Informasi GPU & Driver)
        try:
            result = subprocess.run(
                ['nvidia-smi', '--query-gpu=name', '--format=csv,noheader'],
                capture_output=True,
                text=True,
                timeout=5,
                **get_hide_window_kwargs()
            )
            if result.returncode == 0 and result.stdout.strip():
                gpu_info['has_nvidia_gpu'] = True
                gpu_info['gpu_name'] = result.stdout.strip().split('\n')[0]
                gpu_info['driver_installed'] = True
        except:
            pass
        
        # Method 2: Check System CUDA Toolkit (Check via Path/Env)
        # Seringkali user punya CUDA tapi PyTorch belum diinstall
        cuda_path = os.environ.get('CUDA_PATH') or os.environ.get('CUDA_PATH_V11_8') or os.environ.get('CUDA_PATH_V12_0') or os.environ.get('CUDA_PATH_V12_1')
        if cuda_path and os.path.exists(os.path.join(cuda_path, 'bin', 'nvcc.exe')):
            gpu_info['cuda_available'] = True
            # Ekstrak versi jika memungkinkan
            try:
                if 'v11.8' in cuda_path.lower(): gpu_info['cuda_version'] = '11.8'
                elif 'v12.0' in cuda_path.lower(): gpu_info['cuda_version'] = '12.0'
                elif 'v12.1' in cuda_path.lower(): gpu_info['cuda_version'] = '12.1'
            except: pass

        # Method 3: Check via nvcc command directly
        if not gpu_info['cuda_available']:
            try:
                result = subprocess.run(
                    ['nvcc', '--version'],
                    capture_output=True,
                    text=True,
                    timeout=5,
                    **get_hide_window_kwargs()
                )
                if result.returncode == 0 and 'release' in result.stdout:
                    gpu_info['cuda_available'] = True
            except:
                pass

        # Method 4: Check via PyTorch (Jika sudah terinstall ini yang paling valid untuk runtime)
        try:
            import torch
            if torch.cuda.is_available():
                gpu_info['cuda_available'] = True
                if not gpu_info['has_nvidia_gpu']:
                    gpu_info['has_nvidia_gpu'] = True
                    gpu_info['gpu_name'] = torch.cuda.get_device_name(0)
        except:
            pass
        
        return gpu_info
    
    def check_cuda_available(self):
        """Check if CUDA is available (legacy compatibility)"""
        gpu_info = self.detect_gpu_capability()
        return gpu_info['cuda_available']
    
    def install_pytorch(self, cuda_version, messages, custom_py=None, force=False):
        """Install PyTorch with specific CUDA version"""
        try:
            python_exe = custom_py if custom_py else get_python_exe()
            
            # Check if Python 3.13
            is_py313 = "3.13" in sys.version
            
            # Determine PyTorch URL and Version based on Python Version
            py_ver = sys.version_info
            
            if cuda_version == "cu118":
                torch_url = "https://download.pytorch.org/whl/cu118"
            elif cuda_version == "cu121":
                torch_url = "https://download.pytorch.org/whl/cu121"
            elif cuda_version == "cpu":
                torch_url = "https://download.pytorch.org/whl/cpu"
            else:
                torch_url = "https://download.pytorch.org/whl/cu118"

            if py_ver.major == 3 and py_ver.minor <= 7:
                 # Legacy Pro 2.x (Python <= 3.7)
                torch_spec = "torch==1.10.0 torchvision==0.11.1"
                if cuda_version == "cu118": 
                    # CUDA 11.8 too new for Torch 1.10, switch URL to cu113
                    torch_url = "https://download.pytorch.org/whl/cu113"
            elif py_ver.major == 3 and py_ver.minor < 13:
                # Mainstream Pro 3.x (Python 3.8 - 3.12)
                torch_spec = "torch==2.1.2 torchvision==0.16.2"
            else:
                # Python 3.13+ (Bleeding Edge)
                # Don't pin version for 3.13 as it needs very new versions (2.4+)
                torch_spec = "torch torchvision"
                # Use a more modern CUDA index if not CPU
                if cuda_version != "cpu":
                    torch_url = "https://download.pytorch.org/whl/cu121"
            
            # Install PyTorch
            cmd = [
                python_exe, "-m", "pip", "install",
                *torch_spec.split(),
                "--index-url", torch_url,
                "--extra-index-url", "https://pypi.org/simple",
                "--trusted-host", "pypi.org",
                "--trusted-host", "files.pythonhosted.org",
                "--no-user"
            ]
            
            if force:
                cmd.append("--force-reinstall")
            
            messages.addMessage(f"  Menjalankan: {' '.join(cmd)}")
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=600,
                **get_hide_window_kwargs()
            )
            
            if result.returncode == 0:
                messages.addMessage("  • PyTorch berhasil diinstal")
                return True
            else:
                stderr_lower = result.stderr.lower()
                if "access is denied" in stderr_lower or "permission denied" in stderr_lower:
                    messages.addErrorMessage("\n[ERROR] PERMISSION ERROR: Environment Anda terkunci/read-only.")
                    messages.addErrorMessage("Solusi:")
                    messages.addErrorMessage("1. Tutup ArcGIS Pro.")
                    messages.addErrorMessage("2. Klik Kanan ArcGIS Pro -> Run as Administrator. Jalankan tool lagi.")
                    messages.addErrorMessage("3. ATAU: Clone Environment di Package Manager.")
                    return False
                else:
                    messages.addWarningMessage(f"  [!] Gagal instal PyTorch: {result.stderr[:200]}")
                    return False
                
        except subprocess.TimeoutExpired:
            messages.addWarningMessage("  [!] Timeout saat instal PyTorch")
            return False
        except Exception as e:
            messages.addWarningMessage(f"  [!] Error instal PyTorch: {str(e)}")
            return False
    
    def install_pytorch_alternative(self, cuda_version, messages):
        """Alternative PyTorch installation method"""
        try:
            python_exe = get_python_exe()
            
            # Try without specific index URL
            cmd = [
                python_exe, "-m", "pip", "install",
                "torch==2.1.2", "torchvision==0.16.2",
                "--extra-index-url", "https://download.pytorch.org/whl/cu118",
                "--trusted-host", "pypi.org",
                "--trusted-host", "download.pytorch.org",
                "--force-reinstall", "--no-user"
            ]
            
            messages.addMessage("  Mencoba metode alternatif...")
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300,
                **get_hide_window_kwargs()
            )
            
            if result.returncode == 0:
                messages.addMessage("  • PyTorch berhasil diinstal (metode alternatif)")
                return True
            else:
                messages.addWarningMessage("  [!] Gagal dengan metode alternatif")
                return False
                
        except Exception as e:
            messages.addWarningMessage(f"  [!] Error metode alternatif: {str(e)}")
            return False
    
    def install_fastai(self, messages, custom_py=None, force=False):
        """Install fastai"""
        try:
            python_exe = custom_py if custom_py else get_python_exe()
            
            # Version pinned for stability, unless Python 3.13
            is_py313 = "3.13" in sys.version
            if is_py313:
                # Fastai 2.7.13 is old, let pip find newest for 3.13
                fastai_spec = "fastai"
            else:
                fastai_spec = "fastai==2.7.13"
                
            cmd = [
                python_exe, "-m", "pip", "install", 
                fastai_spec,
                "--extra-index-url", "https://pypi.org/simple",
                "--trusted-host", "pypi.org",
                "--trusted-host", "files.pythonhosted.org",
                "--no-user"
            ]
            
            if force:
                cmd.append("--force-reinstall")
                
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300,
                **get_hide_window_kwargs()
            )
            
            if result.returncode == 0:
                messages.addMessage("  • fastai berhasil diinstal")
                return True
            else:
                if "access is denied" in result.stderr.lower():
                    messages.addErrorMessage("  [!] Permission Error saat instal fastai. Restart ArcGIS Pro.")
                else:
                    messages.addWarningMessage(f"  [!] Gagal instal fastai: {result.stderr[:200]}")
                return False
                
        except Exception as e:
            messages.addWarningMessage(f"  [!] Error instal fastai: {str(e)}")
            return False
    
    def install_other_dependencies(self, messages, custom_py=None, force=False):
        """Install other required libraries"""
        try:
            python_exe = custom_py if custom_py else get_python_exe()
            
            deps = [
                "cryptography", "Pillow", "numpy", "pandas", 
                "scikit-learn", "matplotlib", "scikit-image", "timm"
            ]
            
            for dep in deps:
                # SPECIAL FIX: Python 3.13 + Cryptography + ArcGIS Pro DLL Conflict
                # Cryptography 46.x (Too New) often has DLL issues with ArcGIS Pro's OpenSSL.
                # v43.0.3 is the stable baseline for Python 3.13.
                current_dep = dep
                is_py313 = "3.13" in sys.version
                current_force = force
                
                if dep == "cryptography" and is_py313:
                    current_dep = "cryptography==43.0.3"
                    current_force = True # MUST Force reinstall/downgrade
                
                cmd = [
                    python_exe, "-m", "pip", "install", 
                    current_dep, "--no-user"
                ]
                if current_force:
                    cmd.append("--force-reinstall")
                    
                try:
                    subprocess.run(
                        cmd,
                        capture_output=True,
                        text=True,
                        timeout=120,
                        **get_hide_window_kwargs()
                    )
                except:
                    pass
            
            messages.addMessage("  • Dependensi lain diinstal")
            return True
            
        except Exception as e:
            messages.addWarningMessage(f"  [!] Error instal dependencies: {str(e)}")
            return False

    def clean_user_site_conflicts(self, messages):
        """
        In Python 3.13, we actually WANT our self-contained cryptography 
        in Roaming to bypass ArcGIS Pro's DLL conflicts.
        """
        try:
            import site
            user_site = site.getusersitepackages()
            if os.path.exists(os.path.join(user_site, "cryptography")):
                messages.addMessage("[INFO] Shadow DLL Protection detected in Roaming.")
        except:
            pass

    def clone_environment(self, messages, target_name="DLP-LCL8"):
        """Otomatis melakukan clone environment default ke target baru"""
        try:
            # 1. Cari path conda.exe
            # Biasanya di: C:\Program Files\ArcGIS\Pro\bin\Python\Scripts\conda.exe
            python_exe = get_python_exe()
            pro_bin_python = os.path.dirname(python_exe) # ...\bin\Python\envs\arcgispro-py3
            pro_bin = os.path.dirname(os.path.dirname(os.path.dirname(pro_bin_python))) # ...\bin
            conda_exe = os.path.join(pro_bin, "Python", "Scripts", "conda.exe")
            
            if not os.path.exists(conda_exe):
                # Cari alternatif
                conda_exe = os.path.join(os.path.dirname(sys.executable), "Scripts", "conda.exe")
            
            if not os.path.exists(conda_exe):
                messages.addErrorMessage(f"Conda tidak ditemukan di: {conda_exe}")
                return False

            # 2. Cek apakah target sudah ada dan VALID (punya python.exe)
            messages.addMessage(f"  Mengecek apakah environment '{target_name}' sudah ada...")
            env_py = self.get_env_python(target_name)
            if env_py and os.path.exists(env_py):
                messages.addMessage(f"  [!] Environment '{target_name}' sudah ada dan siap digunakan.")
                return True
            else:
                if env_py:
                    messages.addWarningMessage(f"  [!] Environment '{target_name}' ditemukan tapi korup (python.exe hilang).")
                # Lanjutkan ke kloning (create --clone akan menimpa atau error, tapi 'create' dengan --clone biasanya butuh folder kosong)
                # Untuk aman, biarkan conda yang menangani overwriting jika didukung, atau beri tahu user.
                pass

            # 3. Jalankan Clone
            messages.addMessage(f"  Mulai kloning 'arcgispro-py3' -> '{target_name}'...")
            messages.addMessage("  (Mungkin memakan waktu 5-10 menit, mohon jangan tutup ArcGIS)")
            
            clone_cmd = [conda_exe, "create", "--clone", "arcgispro-py3", "--name", target_name, "--yes"]
            
            # Gunakan Popen agar bisa memberi feedback jika perlu, tapi simpel saja
            result = subprocess.run(
                clone_cmd,
                capture_output=True,
                text=True,
                timeout=1200, # 20 menit limit
                **get_hide_window_kwargs()
            )
            
            if result.returncode == 0:
                messages.addMessage(f"  • Berhasil membuat environment: {target_name}")
                return True
            else:
                messages.addErrorMessage(f"  Gagal kloning: {result.stderr}")
                return False
                
        except Exception as e:
            messages.addErrorMessage(f"  Error sistem saat kloning: {str(e)}")
            return False

    def swap_environment(self, messages, target_name):
        """Gunakan proswap untuk mengganti environment default ArcGIS Pro"""
        try:
            messages.addMessage(f"  Mengaktifkan environment '{target_name}' secara otomatis...")
            
            # Path ke proswap.bat
            # Biasanya di: C:\Program Files\ArcGIS\Pro\bin\Python\Scripts\proswap.bat
            python_exe = get_python_exe()
            pro_bin_python = os.path.dirname(python_exe)
            pro_bin = os.path.dirname(os.path.dirname(os.path.dirname(pro_bin_python)))
            proswap_bat = os.path.join(pro_bin, "Python", "Scripts", "proswap.bat")
            
            if not os.path.exists(proswap_bat):
                # Cari alternatif
                proswap_bat = os.path.join(os.path.dirname(sys.executable), "Scripts", "proswap.bat")
            
            if os.path.exists(proswap_bat):
                cmd = [proswap_bat, target_name]
                subprocess.run(cmd, capture_output=True, **get_hide_window_kwargs())
                messages.addMessage(f"  • Environment '{target_name}' telah diset sebagai default.")
                return True
            else:
                messages.addWarningMessage("  [!] proswap.bat tidak ditemukan. Selesaikan aktivasi manual.")
                return False
        except Exception as e:
            messages.addWarningMessage(f"  [!] Gagal menjalankan proswap: {str(e)}")
            return False

    def get_env_python(self, env_name):
        """Mendapatkan path python.exe dari environment tertarget"""
        try:
            python_exe = get_python_exe()
            pro_bin_python = os.path.dirname(python_exe)
            pro_envs = os.path.dirname(pro_bin_python) # ...\bin\Python\envs
            
            # Cek di folder utama envs
            target_py = os.path.join(pro_envs, env_name, "python.exe")
            if os.path.exists(target_py): return target_py
            
            # Cek di folder User (AppData)
            # Default Local Conda Path: %LOCALAPPDATA%\ESRI\conda\envs
            user_envs = os.path.join(os.environ.get('LOCALAPPDATA', ''), 'ESRI', 'conda', 'envs')
            target_py = os.path.join(user_envs, env_name, "python.exe")
            if os.path.exists(target_py): return target_py
            
            # Gunakan penanda conda untuk mencari
            pro_bin = os.path.dirname(os.path.dirname(os.path.dirname(pro_bin_python)))
            conda_exe = os.path.join(pro_bin, "Python", "Scripts", "conda.exe")
            if os.path.exists(conda_exe):
                res = subprocess.run([conda_exe, "env", "list"], capture_output=True, text=True, **get_hide_window_kwargs())
                for line in res.stdout.splitlines():
                    if env_name in line:
                        parts = line.split()
                        env_path = parts[-1]
                        return os.path.join(env_path, "python.exe")
            
            return None
        except:
            return None
    
    def test_imports(self):
        """Test importing all required modules"""
        modules_to_test = [
            'torch',
            'torchvision',
            'fastai',
            'cryptography',
            'PIL',
            'numpy',
            'pandas'
            # 'arcgis.learn' - Removed because not required for this toolbox & unstable on Py3.13
        ]
        
        results = {}
        for module in modules_to_test:
            try:
                if module == 'PIL':
                    import PIL
                    results[module] = True
                else:
                    importlib.import_module(module)
                    results[module] = True
            except Exception as e:
                results[module] = False
        
        return results

class ManageLandsat8(object):
    def __init__(self):
        """Define the tool (tool name is the name of the class)."""
        self.label = "1. Manage Landsat 8 (Buat Mosaic Dataset)"
        self.category = "01. Data Preparation"
        self.description = "Membuat Mosaic Dataset dari data mentah Landsat 8 (Level 1 atau Level 2)."
        self.canRunInBackground = False

    def getParameterInfo(self):
        """Define parameter definitions"""
        
        # Param 0: Output Geodatabase
        param0 = arcpy.Parameter(
            displayName="Output Geodatabase",
            name="out_gdb",
            datatype="DEWorkspace", 
            parameterType="Required",
            direction="Input"
        )
        param0.filter.list = ["Local Database"]
        
        # Set default ke project workspace
        try:
            aprx = arcpy.mp.ArcGISProject("CURRENT")
            param0.value = aprx.defaultGeodatabase
        except:
            pass

        # Param 1: Mosaic Dataset Name
        param1 = arcpy.Parameter(
            displayName="Mosaic Dataset Name",
            name="mosaic_name",
            datatype="GPString",
            parameterType="Required",
            direction="Input"
        )

        # Param 2: Input Source Data (Folder)
        param2 = arcpy.Parameter(
            displayName="Input Source Data (Folder L8)",
            name="in_folder",
            datatype="DEFolder",
            parameterType="Required",
            direction="Input"
        )

        # Param 3: Dataset Type (Level 1 / Level 2)
        param3 = arcpy.Parameter(
            displayName="Dataset Type",
            name="dataset_type",
            datatype="GPString",
            parameterType="Required",
            direction="Input"
        )
        param3.filter.type = "ValueList"
        param3.filter.list = ["Level 1", "Level 2"]
        param3.value = "Level 2"

        # Param 4: Multispectral (Checkbox)
        param4 = arcpy.Parameter(
            displayName="Multispectral",
            name="multispectral",
            datatype="GPBoolean",
            parameterType="Optional",
            direction="Input"
        )
        param4.value = True

        # Param 5: Pansharpen (Checkbox)
        param5 = arcpy.Parameter(
            displayName="Pansharpen",
            name="pansharpen",
            datatype="GPBoolean",
            parameterType="Optional",
            direction="Input"
        )
        param5.value = False

        # Param 6: Panchromatic (Checkbox)
        param6 = arcpy.Parameter(
            displayName="Panchromatic",
            name="panchromatic",
            datatype="GPBoolean",
            parameterType="Optional",
            direction="Input"
        )
        param6.value = False
        
        # Param 7: Output Mosaic Dataset (Derived)
        param7 = arcpy.Parameter(
            displayName="Output Mosaic Dataset",
            name="out_raster",
            datatype="DERasterDataset",
            parameterType="Derived",
            direction="Output"
        )

        return [param0, param1, param2, param3, param4, param5, param6, param7]

    def isLicensed(self):
        return True

    def updateParameters(self, parameters):
        return

    def updateMessages(self, parameters):
        return

    def execute(self, parameters, messages):
        """Execute the tool"""
        
        # Check License & Print Header
        valid, msg, info = SupabaseGuard.check_license()
        print_license_header(messages, info)
        
        try:
            # SMART PARALLEL PROCESSING
            # Determine RAM size to decide safety
            try:
                import ctypes
                class MEMORYSTATUSEX(ctypes.Structure):
                    _fields_ = [
                        ("dwLength", ctypes.c_ulong),
                        ("dwMemoryLoad", ctypes.c_ulong),
                        ("ullTotalPhys", ctypes.c_ulonglong),
                        ("ullAvailPhys", ctypes.c_ulonglong),
                        ("ullTotalPageFile", ctypes.c_ulonglong),
                        ("ullAvailPageFile", ctypes.c_ulonglong),
                        ("ullTotalVirtual", ctypes.c_ulonglong),
                        ("ullAvailVirtual", ctypes.c_ulonglong),
                        ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
                    ]
                
                stat = MEMORYSTATUSEX()
                stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
                ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))
                
                total_ram_gb = stat.ullTotalPhys / (1024**3)
                
                if total_ram_gb > 24: # High Spec (>24GB RAM, usually 32GB+)
                    arcpy.env.parallelProcessingFactor = "75%" # Safe high performance
                    messages.addMessage(f"[INFO] High Spec System detected ({int(total_ram_gb)}GB RAM). Parallel Processing: ON (75%)")
                else: # Medium/Low Spec (<= 16GB)
                    arcpy.env.parallelProcessingFactor = "0" # Serial (Safe)
                    messages.addMessage(f"[INFO] Standard System detected ({int(total_ram_gb)}GB RAM). Parallel Processing: OFF (Serial Mode for Stability)")
                    
            except:
                # Fallback if detection fails
                arcpy.env.parallelProcessingFactor = "0"
                messages.addMessage("[INFO] Parallel Processing: OFF (Fallback Mode)")
            
            out_gdb = parameters[0].valueAsText
            mosaic_name = parameters[1].valueAsText
            in_folder = parameters[2].valueAsText
            dataset_type = parameters[3].valueAsText
            use_multi = parameters[4].value
            use_pan_sharpen = parameters[5].value
            use_pan = parameters[6].value
            
            # Construct full path
            mosaic_full_path = os.path.join(out_gdb, mosaic_name)
            
            messages.addMessage("")
            messages.addMessage("=" * 60)
            messages.addMessage(f"MANAGE LANDSAT 8 (MOSAIC DATASET) (v{CURRENT_VERSION})")
            messages.addMessage("=" * 60)
            
            # Check if output geodatabase exists
            if not arcpy.Exists(out_gdb):
                messages.addErrorMessage(f"Geodatabase tidak ditemukan: {out_gdb}")
                raise arcpy.ExecuteError
            
            # Check if mosaic already exists and auto-rename (SILENT)
            original_name = mosaic_name
            
            # Pre-emptive check
            counter = 1
            while arcpy.Exists(mosaic_full_path):
                mosaic_name = f"{original_name}_{counter}"
                mosaic_full_path = os.path.join(out_gdb, mosaic_name)
                counter += 1
            
            # ---------------------------------------------------------
            # LOGIC CHANGE: User wants a CLEAN RASTER DATASET, not a MOSAIC.
            # We will create a temporary mosaic, then CopyRaster to final output.
            # ---------------------------------------------------------
            
            final_output_name = mosaic_name
            temp_mosaic_name = f"{final_output_name}_temp_build"
            
            # Check if final output already exists
            final_full_path = os.path.join(out_gdb, final_output_name)
            if arcpy.Exists(final_full_path):
                 # Auto-rename final output logic if needed, or overwrite? 
                 # Let's assume overwrite or unique name logic for strict safety
                 pass

            # Use temp name for the mosaic operations
            mosaic_name = temp_mosaic_name
            mosaic_full_path = os.path.join(out_gdb, mosaic_name)
            
            # Delete temp if exists (cleanup from previous failed run)
            if arcpy.Exists(mosaic_full_path):
                try: arcpy.management.Delete(mosaic_full_path)
                except: pass

            messages.addMessage("")
            messages.addMessage("")
            messages.addMessage(f" GDB          : {os.path.basename(out_gdb)}")
            messages.addMessage(f" Target       : {final_output_name}")
            messages.addMessage(f" Dataset      : {dataset_type}")
            extent_msg = "Environment" if arcpy.env.extent else "Full Extent"
            messages.addMessage(f" Extent       : {extent_msg}")
            messages.addMessage("")
            messages.addMessage("")
            
            # 1. Start Processing (Consolidated Step)
            # FIND ALL MTL FILES (Moved up)
            mtl_files = self.find_all_mtl_files(in_folder)
            scene_count = len(mtl_files)
            messages.addMessage(f" [1] Memproses Data Landsat 8 ({scene_count} Scene Ditemukan)...")
            # messages.addMessage(" [1] Membuat Mosaic Dataset...")
            # Restore SR 4326 (Required Parameter)
            sr = arcpy.SpatialReference(4326) 
            
            created = False
            attempt_count = 0
            max_attempts = 10
            
            while not created and attempt_count < max_attempts:
                try:
                    # Double check existence before creation
                    if arcpy.Exists(mosaic_full_path):
                        # Name collision detected
                        counter += 1
                        mosaic_name = f"{original_name}_{counter}"
                        mosaic_full_path = os.path.join(out_gdb, mosaic_name)
                        continue
                    
                    # Explicit workspace set
                    arcpy.env.workspace = out_gdb
                    
                    # Create and CAPTURE RESULT
                    created_mosaic = arcpy.management.CreateMosaicDataset(
                        in_workspace=out_gdb,
                        in_mosaicdataset_name=mosaic_name,
                        coordinate_system=sr
                    )
                    
                    # Capture the object (or path string from result)
                    mosaic_ds_obj = created_mosaic.getOutput(0)
                    
                    # Force refresh
                    try:
                        arcpy.ClearWorkspaceCache_management()
                        arcpy.RefreshCatalog(out_gdb)
                    except: pass
                    
                    # Final check
                    if not arcpy.Exists(mosaic_ds_obj):
                         # If arcpy magic fails, fallback to string path
                         mosaic_ds_obj = mosaic_full_path
                    
                    created = True
                    parameters[1].value = mosaic_name
                    # messages.addMessage(f"      [OK] Mosaic Dataset berhasil dibuat: {mosaic_name}")
                    
                except Exception as e:
                    # Check for "Table already exists" error (160326)
                    err_str = str(e)
                    if "160326" in err_str or "already exists" in err_str.lower():
                        messages.addMessage(f"      [INFO] Nama '{mosaic_name}' sudah ada (konflik tabel), mencoba nama baru...")
                        counter += 1
                        mosaic_name = f"{original_name}_{counter}"
                        mosaic_full_path = os.path.join(out_gdb, mosaic_name)
                        attempt_count += 1
                    else:
                        messages.addErrorMessage(f"Gagal membuat Mosaic Dataset: {str(e)}")
                        raise e

            if not created:
                messages.addErrorMessage("Gagal membuat Mosaic Dataset setelah beberapa kali percobaan.")
                raise arcpy.ExecuteError
            
            # 2. Add Landsat data (Priority: Single Scene Focus)
            # messages.addMessage(" [2] Mencari data Landsat 8...")
            
            # FIND ALL MTL FILES (Already done above)
            # mtl_files = self.find_all_mtl_files(in_folder)
            
            if not mtl_files:
                messages.addErrorMessage("Tidak ada file MTL Landsat (*_MTL.txt) ditemukan di folder input!")
                raise arcpy.ExecuteError
            
            # User Request: Fix 1 Scene/Path first.
            # We will process all found, but logically this works for 1 or many.
            # messages.addMessage(f"      Ditemukan {len(mtl_files)} scene Landsat.")
            
            success_count = 0
            
            # Loop through scenes
            for idx, mtl_file in enumerate(mtl_files):
                scene_name = os.path.basename(os.path.dirname(mtl_file))
                # messages.addMessage(f"      Menambahkan scene: {scene_name}...")
                
                try:
                    # Capture count before
                    count_before = int(arcpy.management.GetCount(mosaic_ds_obj).getOutput(0))
                    
                    # Attempt 1: Use "Raster Dataset" type instead of "Landsat 8"
                    # The "Landsat 8" raster type has predefined band selections that limit to 4 bands
                    # Using "Raster Dataset" will include ALL bands found in the data
                    
                    # For Level 2, we need to filter ONLY SR bands (B1-B7), exclude B8 (Cirrus), QA, ST, etc.
                    if dataset_type == "Level 2":
                        # Level 2: Only Surface Reflectance bands 1-7
                        # Use multiple filters separated by semicolon
                        band_filter = "*SR_B1.TIF;*SR_B2.TIF;*SR_B3.TIF;*SR_B4.TIF;*SR_B5.TIF;*SR_B6.TIF;*SR_B7.TIF"
                    else:
                        # Level 1: Bands 1-7 (exclude 8=Pan, 9=Cirrus, 10-11=Thermal)
                        band_filter = "*B1.TIF;*B2.TIF;*B3.TIF;*B4.TIF;*B5.TIF;*B6.TIF;*B7.TIF"
                    
                    arcpy.management.AddRastersToMosaicDataset(
                        in_mosaic_dataset=mosaic_ds_obj,
                        raster_type="Raster Dataset",  # Changed from "Landsat 8" to include all bands
                        input_path=scene_dir,  # Use folder path instead of MTL
                        update_cellsize_ranges="UPDATE_CELL_SIZES",
                        update_boundary="UPDATE_BOUNDARY",
                        update_overviews="NO_OVERVIEWS",
                        maximum_pyramid_levels=-1,
                        maximum_cell_size=0,
                        minimum_dimension=1500,
                        spatial_reference=None,
                        filter=band_filter,  # Explicit band list to ensure only 7 bands
                        sub_folder="NO_SUBFOLDERS",
                        duplicate_items_action="ALLOW_DUPLICATES",
                        build_pyramids="BUILD_PYRAMIDS",
                        calculate_statistics="CALCULATE_STATISTICS",
                        build_thumbnails="NO_THUMBNAILS",
                        operation_description="Added Landsat 8 data",
                        force_spatial_reference="NO_FORCE_SPATIAL_REFERENCE",
                        estimate_statistics="ESTIMATE_STATISTICS"
                    )
                    
                    # Check count
                    count_after = int(arcpy.management.GetCount(mosaic_ds_obj).getOutput(0))
                    
                    if count_after > count_before:
                        # messages.addMessage(f"      [OK] Berhasil ditambahkan (File Based).")
                        success_count += 1
                    else:
                        raise Exception("Force fallback to Composite")

                except Exception as e_add:
                    # [OPTIMIZATION]
                    # Direct Fallback to Composite Bands explicitly to ensure Multi-Band integrity
                    # This guarantees that Deep Learning tools receive a proper N-Band stacked raster
                    try:
                        self.add_rasters_alternative_enhanced(mosaic_ds_obj, os.path.dirname(mtl_file), out_gdb, messages)
                        success_count += 1
                    except Exception as e_alt:
                        messages.addErrorMessage(f"      [ERR] Scene {scene_name} gagal total: {str(e_alt)}")

                except Exception as e_add:
                    # Silent info instead of warning
                    # messages.addMessage(f"      [INFO] Metode MTL Standard tidak support struktur file ini. Beralih ke Alternatif...")
                    # messages.addMessage("      Mencoba via Composite Bands (Alternatif)...")
                    
                    try:
                        # Fallback: Create composite in scratch folder, NOT inside GDB folder structure
                        self.add_rasters_alternative_enhanced(mosaic_ds_obj, os.path.dirname(mtl_file), out_gdb, messages)
                        success_count += 1
                    except Exception as e_alt:
                        messages.addErrorMessage(f"      [ERR] Scene {scene_name} gagal total: {str(e_alt)}")

            # Post-Add Check
            final_count = 0
            try:
                final_count = int(arcpy.management.GetCount(mosaic_ds_obj).getOutput(0))
                # messages.addMessage(f"      Total data di Mosaic: {final_count}")
            except:
                pass
            
            # If nothing added, we warn but don't crash - let user investigate logs
            if final_count == 0:
                 messages.addErrorMessage("PERINGATAN: Mosaic Dataset kosong. Cek log untuk detail error per scene.")

            # 3. Build statistics
            # messages.addMessage(" [3] Membangun statistik...")
            try:
                # messages.addMessage("  Menghitung statistik...")
                arcpy.management.CalculateStatistics(
                    in_raster_dataset=mosaic_ds_obj,
                    x_skip_factor="1",
                    y_skip_factor="1",
                    ignore_values="",
                    skip_existing="OVERWRITE"
                )
                # messages.addMessage("      [OK] Statistik berhasil dibangun")
                
            except Exception as stat_err:
                # Try alternative method if stats failed
                try:
                    messages.addMessage("  Mencoba metode alternatif (Build Pyramids per item)...")
                    with arcpy.da.SearchCursor(mosaic_ds_obj, ["Name", "Raster"]) as cursor:
                        for row in cursor:
                            try:
                                if row[1]: arcpy.management.BuildPyramids(row[1])
                            except: pass
                    arcpy.management.CalculateStatistics(mosaic_ds_obj)
                except:
                    pass  # Silent fail
            
            # 4. Set properties
            # messages.addMessage(" [4] Mengatur properti Mosaic Dataset...")
            
            try:
                # Use Environment Extent if set
                extent_used = None
                if arcpy.env.extent:
                    try:
                        extent_used = arcpy.env.extent
                        messages.addMessage(f"  [OK] Menggunakan Environment Extent")
                    except: pass
                
                # Apply extent-based clipping - DISABLED to prevent holes
                if extent_used:
                    try:
                        # arcpy.management.BuildBoundary(
                        #     in_mosaic_dataset=mosaic_ds_obj,
                        #     simplification_method="NONE"
                        # )
                        # arcpy.management.SetMosaicDatasetProperties(
                        #     mosaic_ds_obj,
                        #     clip_to_boundary="CLIP"
                        # )
                        # messages.addMessage("  [OK] Boundary dibangun dan clipping diaktifkan")
                        pass
                    except: pass
                
                # Set other properties
                try:
                    basic_props = {
                        'rows_maximum_imagesize': 4096,
                        'columns_maximum_imagesize': 4096,
                        'allowed_compressions': "JPEG;LZ77;NONE",
                        'default_compression_type': "JPEG",
                        'JPEG_quality': 80,
                        'resampling_type': "NEAREST",
                        'LERC_Tolerance': 0.01,
                        'cell_size_tolerance': 1.5
                    }
                    arcpy.management.SetMosaicDatasetProperties(mosaic_ds_obj, **basic_props)
                    
                    # Try to set processing template - DISABLED to preserve RAW DN
                    # template = None
                    # if use_pan_sharpen: template = "Pansharpen"
                    # elif use_pan: template = "Panchromatic"
                    # elif use_multi: template = "Multispectral"
                    
                    # if template:
                    #     try:
                    #         arcpy.management.SetMosaicDatasetProperties(mosaic_ds_obj, default_processing_template=template)
                    #         messages.addMessage(f"  [OK] Processing template: {template}")
                    #     except: pass
                    
                    # Ensure NO Processing Template is applied (None)
                    # REVERT: Setting text "None" might crash CopyRaster if template doesn't exist.
                    # We rely on NoData fix for the holes.
                    # arcpy.management.SetMosaicDatasetProperties(mosaic_ds_obj, default_processing_template="None")
                    pass
                    
                except: pass
                
            except Exception as e:
                messages.addWarningMessage(f"[WARN] Error pengaturan properti: {str(e)[:150]}")
            
            # 5. Convert to Raster Dataset (Clean Output)
            messages.addMessage(" [2] Finalisasi Output (Raster Dataset)...")
            
            try:
                final_raster_path = os.path.join(out_gdb, final_output_name)
                
                # Pre-flight checks (silent)
                try:
                    import shutil
                    total, used, free = shutil.disk_usage(os.path.dirname(out_gdb))
                    free_gb = free // (2**30)
                    if free_gb < 5:
                        messages.addWarningMessage(f"      [WARN] Low disk space: {free_gb} GB free (minimum 5 GB recommended)")
                except:
                    pass
                
                # Compact GDB (silent)
                try:
                    arcpy.management.Compact(out_gdb)
                except:
                    pass
                
                # Delete existing output
                if arcpy.Exists(final_raster_path):
                    try:
                        arcpy.management.Delete(final_raster_path)
                    except Exception as del_err:
                        # Force delete with compact
                        try:
                            arcpy.management.Compact(out_gdb)
                            arcpy.management.Delete(final_raster_path)
                        except:
                            pass

                # Copy Raster (Converts Mosaic -> Raster Dataset)
                # METHOD CHANGE: Always use 'Intermediate TIFF' method for stability on low-RAM machines.
                # Direct GDB-to-GDB conversion often crashes ArcGIS Pro.
                # LOW RAM SAFETY VALVE (ANTI-CRASH)
                # If RAM <= 24GB, skip the heavy 'CopyRaster' process entirely.
                # Just return the Mosaic Dataset. It works fine for Deep Learning.
                try:
                    import ctypes
                    class MEMORYSTATUSEX(ctypes.Structure):
                        _fields_ = [("dwLength", ctypes.c_ulong),("dwMemoryLoad", ctypes.c_ulong),("ullTotalPhys", ctypes.c_ulonglong),("ullAvailPhys", ctypes.c_ulonglong),("ullTotalPageFile", ctypes.c_ulonglong),("ullAvailPageFile", ctypes.c_ulonglong),("ullTotalVirtual", ctypes.c_ulonglong),("ullAvailVirtual", ctypes.c_ulonglong),("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
                    stat = MEMORYSTATUSEX()
                    stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
                    ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))
                    ram_gb = stat.ullTotalPhys / (1024**3)
                    
                    if ram_gb <= 24:
                        messages.addMessage(f"[INFO] System RAM ({int(ram_gb)}GB) <= 24GB.")
                        messages.addMessage("[INFO] Skipping 'Single Raster Conversion' to prevent memory crash.")
                        messages.addMessage("[INFO] Output saved as MOSAIC DATASET (This is VALID for Deep Learning).")
                        
                        parameters[7].value = mosaic_full_path # Return Mosaic path instead
                        return # EXIT HAPPILY
                        
                except:
                    pass # Continue check if fails

                copy_success = False
                try:
                    # Step 1: Export to Temp TIFF (Flat file outside GDB)
                    # messages.addMessage("      [INFO] Exporting to Temporary TIFF (Safe Mode)...")
                    temp_tiff = os.path.join(arcpy.env.scratchFolder, f"{final_output_name}_{uuid.uuid4().hex[:6]}.tif")
                    
                    if os.path.exists(temp_tiff):
                        try: os.remove(temp_tiff)
                        except: pass
                    
                    # Force calculate statistics on mosaic first to ensure readable
                    try: arcpy.management.CalculateStatistics(mosaic_ds_obj)
                    except: pass

                    arcpy.management.CopyRaster(
                        in_raster=mosaic_ds_obj,
                        out_rasterdataset=temp_tiff,
                        pixel_type="16_BIT_UNSIGNED",
                        format="TIFF",
                        compression_type="NONE" # Disable compression for max speed/stability during temp write
                    )
                    
                    # Step 2: Import TIFF back to GDB
                    # messages.addMessage("      [INFO] Importing to Final Location...")
                    arcpy.management.CopyRaster(
                        in_raster=temp_tiff,
                        out_rasterdataset=final_raster_path,
                        pixel_type="16_BIT_UNSIGNED",
                        format="", # GDB Raster
                        compression_type="LZ77" # Efficient storage for GDB
                    )
                    
                    # Cleanup
                    try: os.remove(temp_tiff)
                    except: pass
                        
                    copy_success = True
                    
                except Exception as tiff_err:
                     # messages.addWarningMessage(f"      [WARN] Safe Mode failed: {str(tiff_err)}. Trying fallback...")
                     pass
                     
                if not copy_success:
                    try:
                        # Fallback: Direct CopyRaster (Risky but last resort)
                        arcpy.management.CopyRaster(
                            in_raster=mosaic_ds_obj,
                            out_rasterdataset=final_raster_path,
                            pixel_type="16_BIT_UNSIGNED",
                            format="",
                            compression_type="LZ77"
                        )
                        copy_success = True
                    except Exception as copy_err:
                        pass
                    
                    # Method 3: Direct band composite
                    if not copy_success:
                        try:
                            desc = arcpy.Describe(mosaic_ds_obj)
                            band_count = desc.bandCount
                            
                            band_rasters = []
                            for i in range(1, band_count + 1):
                                band_path = os.path.join(arcpy.env.scratchGDB, f"band_{i}_temp")
                                if arcpy.Exists(band_path):
                                    arcpy.management.Delete(band_path)
                                    
                                arcpy.management.MakeRasterLayer(mosaic_ds_obj, f"band_{i}_lyr", band_index=i)
                                arcpy.management.CopyRaster(f"band_{i}_lyr", band_path, pixel_type="16_BIT_UNSIGNED")
                                band_rasters.append(band_path)
                            
                            arcpy.management.CompositeBands(band_rasters, final_raster_path)
                            
                            for band_path in band_rasters:
                                try:
                                    arcpy.management.Delete(band_path)
                                except:
                                    pass
                            
                            copy_success = True
                            
                        except Exception as comp_err:
                            messages.addErrorMessage(f"      [ERROR] Conversion failed: {str(comp_err)[:200]}")
                
                if not copy_success:
                    raise Exception("All conversion methods failed. Check disk space, GDB integrity, and permissions.")
                
                 # Set output parameter
                parameters[7].value = final_raster_path
                
                # Remove NoData mask
                # Level 1: NoData is usually NULL
                # Level 2: NoData is usually exact 0 (fill value), not negative or low values
                # messages.addMessage("      [INFO] Removing NoData...")
                try:
                    if arcpy.CheckExtension("Spatial") == "Available":
                        arcpy.CheckOutExtension("Spatial")
                        
                        temp_nodata_free = final_raster_path + "_temp"
                        
                        from arcpy.sa import Con, IsNull, Raster
                        
                        # Convert path to Raster object
                        input_raster = Raster(final_raster_path)
                        
                        if dataset_type == "Level 2":
                            # Level 2: Replace EXACT 0 (fill value) only, not low values
                            # This preserves valid dark pixels (shadows, deep water)
                            # SR valid range: 7273-43636, but dark pixels can be lower (1-7000)
                            nodata_removed = Con((input_raster == 0) | IsNull(input_raster), 1, input_raster)
                        else:
                            # Level 1: Replace NULL with 0
                            nodata_removed = Con(IsNull(input_raster), 0, input_raster)
                        
                        nodata_removed.save(temp_nodata_free)
                        
                        arcpy.management.Delete(final_raster_path)
                        arcpy.management.Rename(temp_nodata_free, final_raster_path)
                        
                        arcpy.CheckInExtension("Spatial")
                        # messages.addMessage("      [OK] NoData removed")
                    else:
                        # Fallback: SetRasterProperties
                        if dataset_type == "Level 2":
                            arcpy.management.SetRasterProperties(final_raster_path, nodata="1 0")  # Treat 0 as NoData
                        else:
                            arcpy.management.SetRasterProperties(final_raster_path, nodata="1 65536")
                except Exception as nodata_err:
                    messages.addWarningMessage(f"      [WARN] NoData removal failed: {str(nodata_err)[:100]}")
                    # Silent fallback
                    try:
                        if dataset_type == "Level 2":
                            arcpy.management.SetRasterProperties(final_raster_path, nodata="1 0")
                        else:
                            arcpy.management.SetRasterProperties(final_raster_path, nodata="1 65536")
                    except:
                        pass
                
                # Re-Calculate Statistics & Pyramids (CRITICAL FOR PERFORMANCE)
                # Since we modified the pixel values (NoData), we must rebuild stats
                try:
                    # messages.addMessage("      [INFO] Calculating Statistics & Pyramids...")
                    arcpy.management.CalculateStatistics(final_raster_path)
                    arcpy.management.BuildPyramids(final_raster_path)
                except:
                    pass

                # Cleanup Temp Mosaic (silent)
                try:
                    arcpy.management.Delete(mosaic_ds_obj)
                except:
                    pass

                messages.addMessage("")
                messages.addMessage("")
                messages.addMessage("=" * 60)
                messages.addMessage(" PROSES SELESAI")
                messages.addMessage("=" * 60)
                messages.addMessage(f" Raster       : {final_output_name}")
                messages.addMessage(f" Path         : {final_raster_path}")
                messages.addMessage(f" Dataset      : {dataset_type}")
                messages.addMessage(f" Multispectral: {'Ya' if use_multi else 'Tidak'}")
                messages.addMessage(f" Pansharpen   : {'Ya' if use_pan_sharpen else 'Tidak'}")
                messages.addMessage("=" * 60)
                messages.addMessage("")

            except Exception as e_copy:
                 messages.addErrorMessage(f"Gagal Konversi Raster: {str(e_copy)}")
                 # Fallback: Return the mosaic if copy failed
                 parameters[7].value = mosaic_ds_obj 

            return
                

            
        except Exception as e:
            messages.addErrorMessage(f"Error: {str(e)}")
            raise arcpy.ExecuteError

    def find_all_mtl_files(self, folder_path):
        """Find all MTL files in Landsat folder recursively (Prefer XML for Collection 2)"""
        mtl_files = []
        for root, dirs, files in os.walk(folder_path):
            # Collections 2 often has _MTL.xml which works better in Pro
            xml_found = False
            for file in files:
                if file.upper().endswith("_MTL.XML"):
                    mtl_files.append(os.path.join(root, file))
                    xml_found = True
                    break # One metadata per folder is enough
            
            if not xml_found:
                for file in files:
                    if file.upper().endswith("_MTL.TXT") or file.upper().endswith("MTL.TXT"):
                        mtl_files.append(os.path.join(root, file))
                        break

        return mtl_files

    def add_rasters_alternative_enhanced(self, mosaic_ds_obj, input_folder, out_gdb, messages):
        """Alternative method: Composite Bands properly stored in GDB (Permanent)"""
        
        # 1. Gather TIFs
        tif_files = []
        for root, dirs, files in os.walk(input_folder):
            for file in files:
                if file.lower().endswith('.tif'):
                    tif_files.append(os.path.join(root, file))
        
        if not tif_files:
            raise Exception("Tidak ada file TIF ditemukan untuk composite.")
            
        # 2. Filter Bands
        band_map = {}
        for tif_file in tif_files:
            filename = os.path.basename(tif_file).upper()
            for i in range(1, 12):
                if f"_B{i}.TIF" in filename or f"_SR_B{i}" in filename:
                    try:
                        # Avoid duplicates
                        if i not in band_map: band_map[i] = tif_file
                    except: pass
        
        if len(band_map) < 3:
            raise Exception(f"Hanya ditemukan band: {list(band_map.keys())}. Minimal 3 band untuk composite.")

        # 3. Create Composite PERMANENTLY in Output GDB
        # Because Mosaic Dataset references data, we CANNOT delete the source.
        sorted_bands = [band_map[i] for i in sorted(band_map.keys())]
        
        # Generate unique name for the composite raster
        scene_name = os.path.basename(input_folder)
        # Sanitize name
        safe_name = "".join(x for x in scene_name if x.isalnum() or x == "_")
        if not safe_name: safe_name = "Scene"
        
        # Unique ID to prevent collision
        comp_name = f"Comp_{safe_name}_{random.randint(100, 999)}"
        
        permanent_composite = os.path.join(out_gdb, comp_name)
        
        # messages.addMessage(f"      Membuat Composite Raster Permanen: {comp_name}...")
        
        try:
            arcpy.management.CompositeBands(sorted_bands, permanent_composite)
            
            # 4. Add to Mosaic
            # messages.addMessage("      Menambahkan ke Mosaic Dataset...")
            arcpy.management.AddRastersToMosaicDataset(
                in_mosaic_dataset=mosaic_ds_obj,
                raster_type="Raster Dataset",
                input_path=permanent_composite,
                duplicate_items_action="ALLOW_DUPLICATES",
                update_overviews="UPDATE_OVERVIEWS" # Try to update overviews explicitly
            )
            
            # messages.addMessage("      [OK] Berhasil. Source raster tersimpan di GDB.")
            
        except Exception as e:
            raise Exception(f"Gagal saat Composite/Add: {str(e)}")
            
        # NO DELETION! Mosaic needs this file.

class ClassifyLandCover(object):
    def __init__(self):
        """Define the tool (tool name is the name of the class)."""
        self.label = "2. Klasifikasi Tutupan Lahan (Deep Learning)"
        self.category = "02. Classification"
        self.description = "Melakukan klasifikasi piksel menggunakan model Deep Learning (.dlpk) yang sudah dilatih."
        self.canRunInBackground = False

    def getParameterInfo(self):
        """Define parameter definitions"""
        
        # Param 0: Input Raster
        param0 = arcpy.Parameter(
            displayName="Input Raster (Layer/Mosaic Dataset)",
            name="in_raster",
            datatype=["GPCompositeLayer", "GPRasterLayer", "DEMosaicDataset", "DERasterDataset"],
            parameterType="Required",
            direction="Input"
        )
        
        # Param 1: Model Definition
        param1 = arcpy.Parameter(
            displayName="File Model Deep Learning (.dlpk atau .emd)",
            name="in_model_definition",
            datatype="DEFile",
            parameterType="Required",
            direction="Input"
        )
        param1.filter.list = ['dlpk', 'emd']

        # Param 2: Output Raster
        param2 = arcpy.Parameter(
            displayName="Output Raster Klasifikasi",
            name="out_classified_raster",
            datatype="DERasterDataset",
            parameterType="Required",
            direction="Output"
        )
        
        # --- Advanced Parameters ---
        
        # Param 3: Processing Mode
        param3 = arcpy.Parameter(
            displayName="Processing Mode",
            name="processing_mode",
            datatype="GPString",
            parameterType="Optional",
            direction="Input"
        )
        param3.filter.type = "ValueList"
        param3.filter.list = ["PROCESS_AS_MOSAICKED_IMAGE", "PROCESS_AS_RASTER", "PROCESS_ITEMS_SEPARATELY"]
        param3.value = "PROCESS_AS_MOSAICKED_IMAGE"
        
        # Param 4: Padding
        param4 = arcpy.Parameter(
            displayName="Padding",
            name="padding",
            datatype="GPLong",
            parameterType="Optional",
            direction="Input"
        )
        param4.value = 64
        
        # Param 5: Batch Size
        param5 = arcpy.Parameter(
            displayName="Batch Size",
            name="batch_size",
            datatype="GPLong",
            parameterType="Optional",
            direction="Input"
        )
        param5.value = 4
        
        # Param 6: Threshold
        param6 = arcpy.Parameter(
            displayName="Threshold (Confidence)",
            name="threshold",
            datatype="GPDouble",
            parameterType="Optional",
            direction="Input"
        )
        param6.value = 0.5
        
        # Param 7: Predict Background
        param7 = arcpy.Parameter(
            displayName="Predict Background",
            name="predict_background",
            datatype="GPBoolean",
            parameterType="Optional",
            direction="Input"
        )
        param7.value = True
        
        # Param 8: Test Time Augmentation
        param8 = arcpy.Parameter(
            displayName="Test Time Augmentation",
            name="test_time_augmentation",
            datatype="GPBoolean",
            parameterType="Optional",
            direction="Input"
        )
        param8.value = True
        
        # Param 9: Tile Size
        param9 = arcpy.Parameter(
            displayName="Tile Size",
            name="tile_size",
            datatype="GPLong",
            parameterType="Optional",
            direction="Input"
        )
        param9.value = 512
        
        # Param 10: Processor Type
        param10 = arcpy.Parameter(
            displayName="Processor Type",
            name="processor_type",
            datatype="GPString",
            parameterType="Optional",
            direction="Input"
        )
        param10.filter.type = "ValueList"
        param10.filter.list = ["GPU", "CPU"]
        param10.value = "GPU"
        
        # Param 11: Use only CPU cores
        param11 = arcpy.Parameter(
            displayName="Number of CPU Cores",
            name="cpu_cores",
            datatype="GPLong",
            parameterType="Optional",
            direction="Input"
        )
        param11.value = 4
        
        # --- Polygon Conversion Parameters ---
        
        # Param 12: Convert to Polygon
        param12 = arcpy.Parameter(
            displayName="Convert to Polygon (Vector)",
            name="convert_to_polygon",
            datatype="GPBoolean",
            parameterType="Optional",
            direction="Input"
        )
        param12.value = True
        
        # Param 13: Simplify Polygon
        param13 = arcpy.Parameter(
            displayName="Simplify Polygon (Smooth Edges)",
            name="simplify_polygon",
            datatype="GPBoolean",
            parameterType="Optional",
            direction="Input"
        )
        param13.value = True
        
        # Param 14: Output Standard (SNI)
        param14 = arcpy.Parameter(
            displayName="Output Classification Standard",
            name="output_standard",
            datatype="GPString",
            parameterType="Optional",
            direction="Input"
        )
        param14.filter.type = "ValueList"
        param14.filter.list = ["Original (Esri)", "SNI Indonesia (1:50.000)"]
        param14.value = "SNI Indonesia (1:50.000)"

        return [param0, param1, param2, param3, param4, param5, param6, param7, 
                param8, param9, param10, param11, param12, param13, param14]

    def isLicensed(self):
        """Check for required licenses"""
        try:
            if arcpy.CheckExtension("ImageAnalyst") == "Available":
                return True
            if arcpy.CheckExtension("Spatial") == "Available":
                return True
        except:
            pass
        return False

    def updateParameters(self, parameters):
        """Modify parameters"""
        return

    def updateMessages(self, parameters):
        """Modify messages"""
        # Check license
        if not self.isLicensed():
            parameters[0].setErrorMessage(
                "Tool ini membutuhkan lisensi Image Analyst atau Spatial Analyst."
            )
        
        # Check if model file exists
        if parameters[1].valueAsText:
            model_path = parameters[1].valueAsText
            if not os.path.exists(model_path):
                parameters[1].setErrorMessage("File model tidak ditemukan!")
        return

    def execute(self, parameters, messages):
        """Execute the tool"""
        
        # FIX CRASH: Force Allow Duplicate OpenMP Libraries (MKL Issue)
        os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
        
        # 0. PYTHON 3.13 STABILITY (FINAL RESOLUTION)
        # We use a Shadow DLL strategy in AppData/Roaming to bypass ArcGIS Pro's OpenSSL conflicts.
        try:
            import site
            user_site = site.getusersitepackages()
            if os.path.exists(user_site):
                # Ensure User Site is ENABLED in current process
                if user_site not in sys.path:
                    sys.path.insert(0, user_site)
                # PROPAGATE to Child Processes (Raster Function workers)
                existing_pp = os.environ.get('PYTHONPATH', '')
                if user_site not in existing_pp:
                    os.environ['PYTHONPATH'] = f"{user_site};{existing_pp}"
                messages.addMessage("[INFO] Shadow DLL Protection Active (Roaming Mode).")
        except: pass

        # Check License & Display Header FIRST
        valid, msg, info = SupabaseGuard.check_license()
        print_license_header(messages, info)

        try:
            # RAM DETECTION FIX (For 64-bit System)
            import ctypes
            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [
                    ("dwLength", ctypes.c_uint),
                    ("dwMemoryLoad", ctypes.c_uint),
                    ("ullTotalPhys", ctypes.c_uint64),
                    ("ullAvailPhys", ctypes.c_uint64),
                    ("ullTotalPageFile", ctypes.c_uint64),
                    ("ullAvailPageFile", ctypes.c_uint64),
                    ("ullTotalVirtual", ctypes.c_uint64),
                    ("ullAvailVirtual", ctypes.c_uint64),
                    ("ullAvailExtendedVirtual", ctypes.c_uint64)
                ]
            stat = MEMORYSTATUSEX()
            stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))
            total_ram_gb = stat.ullTotalPhys / (1024**3)
            
            if total_ram_gb > 24:
                messages.addMessage(f"[INFO] System: {int(total_ram_gb)}GB RAM detected.")
                arcpy.env.parallelProcessingFactor = "0"
                messages.addMessage("[INFO] Mode Stabilitas Aktif: Menjalankan Klasifikasi (Serial Mode).")
            else:
                arcpy.env.parallelProcessingFactor = "0"
        except:
            arcpy.env.parallelProcessingFactor = "0"

        # Get parameters
        try:
            in_raster = parameters[0].valueAsText
            in_model = parameters[1].valueAsText
            out_raster = parameters[2].valueAsText
            
            # Advanced parameters
            proc_mode = parameters[3].valueAsText
            padding = parameters[4].value
            batch_size = parameters[5].value
            threshold = parameters[6].value
            predict_bg = parameters[7].value
            tta = parameters[8].value
            tile_size = parameters[9].value
            processor_type = parameters[10].valueAsText
            cpu_cores = parameters[11].value
            convert_to_polygon = parameters[12].value
            simplify_polygon = parameters[13].value
            output_standard = parameters[14].valueAsText
            
            # HARDCODED: Always treat as Level 2
            landsat_level = 2
            
            # Tool Header Box
            messages.addMessage("")
            messages.addMessage("=" * 60)
            messages.addMessage(f"DEEP LEARNING LAND COVER TOOLBOX v{CURRENT_VERSION}")
            messages.addMessage("=" * 60)
            messages.addMessage("PEMERIKSAAN STATUS LISENSI")
            messages.addMessage("=" * 60)
            messages.addMessage("\n[1] PEMERIKSAAN SISTEM")
            messages.addMessage("-" * 60)
            
            # AUTO-FIX PATH (Library Injection & Propagation)
            import site
            try:
                user_site = site.getusersitepackages()
                if user_site not in sys.path:
                    sys.path.append(user_site)
                
                # IMPORTANT: Propagate to Child Processes (Raster Function) via PYTHONPATH
                existing_pp = os.environ.get('PYTHONPATH', '')
                if user_site not in existing_pp:
                    os.environ['PYTHONPATH'] = f"{user_site};{existing_pp}"

                # Also check standard site-packages
                env_site = os.path.join(sys.prefix, 'Lib', 'site-packages')
                if env_site not in sys.path:
                    sys.path.append(env_site)
                if env_site not in os.environ.get('PYTHONPATH', ''):
                     os.environ['PYTHONPATH'] = f"{env_site};{os.environ.get('PYTHONPATH', '')}"
                     
            except: pass

            # Check Dependencies
            deps_ok = True
            missing_dep = ""
            try:
                import torch
                import torchvision
                import fastai
                # NOTE: Don't import fastai.vision.all - only exists in v2.x
                # We support both v1.x and v2.x
            except ImportError as e:
                deps_ok = False
                missing_dep = str(e)
            except Exception as e:
                deps_ok = False
                missing_dep = str(e)
            
            if not deps_ok:
                # Soft Exit (Don't raise Fatal Error to prevent App Crash)
                messages.addErrorMessage("[ERR] DEPENDENSI TIDAK LENGKAP / ERROR!")
                messages.addErrorMessage(f"Detail: {missing_dep}")
                messages.addErrorMessage("Solusi: Jalankan tool '02. Install Deep Learning Libraries'.")
                return # Just stop politely
            else:
                messages.addMessage(f" - PyTorch: {torch.__version__}")
                messages.addMessage(f" - FastAI : {fastai.__version__}")
                messages.addMessage("[OK] Dependensi: Terinstall")
            
            # Check License
            license_checked = False
            if arcpy.CheckExtension("ImageAnalyst") == "Available":
                arcpy.CheckOutExtension("ImageAnalyst")
                messages.addMessage("[OK] Lisensi: Image Analyst (Aktif)")
                license_checked = True
            elif arcpy.CheckExtension("Spatial") == "Available":
                arcpy.CheckOutExtension("Spatial")
                messages.addMessage("[OK] Lisensi: Spatial Analyst (Aktif)")
                license_checked = True
            
            if not license_checked:
                messages.addErrorMessage("[ERR] Tidak ada lisensi yang tersedia!")
                raise arcpy.ExecuteError
            
            # ====================================================================
            # 2. VALIDATE INPUTS
            # ====================================================================
            # Check if input raster exists
            if not arcpy.Exists(in_raster):
                messages.addErrorMessage(f"[ERR] Raster input tidak ditemukan: {in_raster}")
                raise arcpy.ExecuteError
            
            # Check if model file exists
            if not os.path.exists(in_model):
                messages.addErrorMessage(f"[ERR] File model tidak ditemukan: {in_model}")
                raise arcpy.ExecuteError
            
            # ====================================================================
            # 4. PREPARE ARGUMENTS (Hidden)
            # ====================================================================
            
            # Build arguments string
            args_dict = {
                'padding': padding,
                'batch_size': batch_size,
                'threshold': threshold,
                'predict_background': str(predict_bg).lower() if isinstance(predict_bg, bool) else predict_bg,
                'test_time_augmentation': str(tta).lower() if isinstance(tta, bool) else tta,
                'tile_size': tile_size,
                'landsat_imagery_level': landsat_level,
                'processor_type': processor_type.lower()
            }
            
            # Filter out None values
            args_dict = {k: v for k, v in args_dict.items() if v is not None}
            
            # Convert to string format
            args_list = [f"{k} {v}" for k, v in args_dict.items()]
            args_str = ";".join(args_list)
            
            # ====================================================================
            # 5. SET ENVIRONMENT (Hidden)
            # ====================================================================
            
            # Save current environment
            old_workspace = arcpy.env.workspace
            old_cellSize = arcpy.env.cellSize
            old_extent = arcpy.env.extent
            old_scratch = arcpy.env.scratchWorkspace
            
            try:
                # Set environment for deep learning
                arcpy.env.workspace = os.path.dirname(out_raster)
                arcpy.env.cellSize = in_raster
                # DON'T override extent - preserve user's AOI setting
                arcpy.env.scratchWorkspace = arcpy.env.scratchFolder if hasattr(arcpy.env, 'scratchFolder') else old_scratch
                
                # Set processor type
                if processor_type == "GPU":
                    arcpy.env.processorType = "GPU"
                else:
                    arcpy.env.processorType = "CPU"
                    arcpy.env.parallelProcessingFactor = str(cpu_cores)
                
            except:
                pass # Silent fail
            
            # ====================================================================
            # 6. RUN CLASSIFICATION
            # ====================================================================
            messages.addMessage("\n[2] PEMROSESAN")
            messages.addMessage("-" * 60)
            messages.addMessage("Menjalankan Klasifikasi Deep Learning...")
            messages.addMessage(f"[INFO] Backend: {processor_type}")
            
            start_time = time.time()
            
            try:
                # Ensure output path is safe
                if arcpy.Exists(out_raster):
                    try:
                        arcpy.Delete_management(out_raster)
                        # messages.addMessage(f"  File lama dihapus: {out_raster}")
                    except:
                        # If delete fails, generate unique name
                        base, ext = os.path.splitext(os.path.basename(out_raster))[0]
                        timestamp = time.strftime("%Y%m%d_%H%M%S")
                        out_raster = f"{base}_{timestamp}{ext}"
                        messages.addWarningMessage(f"[WARN] Output dialihkan ke: {os.path.basename(out_raster)}")

                # Enable overwrite
                arcpy.env.overwriteOutput = True

                # Smart pre-clipping: Clip by extent if AOI is set
                # Deep Learning tools tend to ignore environment extent when mode is Process as Mosaicked Image
                processing_raster = in_raster 
                temp_clipped = None # Initialize variable to avoid UnboundLocalError
                
                if old_extent and str(old_extent) != "MAXOF" and str(old_extent).upper() != "DEFAULT":
                    try:
                        # Format extent for display (hide NaN Z/M values)
                        clean_extent_str = f"{old_extent.XMin} {old_extent.YMin} {old_extent.XMax} {old_extent.YMax}"
                        # messages.addMessage(f"[INFO] Processing Extent Detected: {clean_extent_str}")
                        # messages.addMessage("      [INFO] Preparing efficient clip operation...")
                        
                        # 1. Create a Polygon from the Extent (in memory or scratch)
                        # This allows us to Project it safely to whatever the Raster CRS is.
                        
                        # Get Input Raster Properties
                        desc = arcpy.Describe(in_raster)
                        input_sr = desc.spatialReference
                        
                        # Create Polygon Geometry from Extent
                        extent_poly = arcpy.Polygon(
                            arcpy.Array([
                                arcpy.Point(old_extent.XMin, old_extent.YMin),
                                arcpy.Point(old_extent.XMin, old_extent.YMax),
                                arcpy.Point(old_extent.XMax, old_extent.YMax),
                                arcpy.Point(old_extent.XMax, old_extent.YMin)
                            ]),
                            old_extent.spatialReference
                        )
                        
                        # Project if needed (Geometry projectAs is reliable)
                        if old_extent.spatialReference.factoryCode != input_sr.factoryCode:
                            # messages.addMessage(f"      [INFO] Projecting clipping area to match raster ({input_sr.name})...")
                            extent_poly = extent_poly.projectAs(input_sr)
                        
                        # Save to temp feature class for Clip tool input
                        temp_poly_fc = os.path.join(arcpy.env.scratchGDB, f"clip_poly_{uuid.uuid4().hex[:8]}")
                        arcpy.management.CopyFeatures(extent_poly, temp_poly_fc)
                        
                        # Prepare output raster path
                        temp_clipped_name = f"clip_{uuid.uuid4().hex[:8]}"
                        temp_clipped = os.path.join(arcpy.env.scratchGDB, temp_clipped_name)
                        
                        # messages.addMessage("      [INFO] Clipping input raster...")
                        
                        # Optimization: Enable Compression for Speed
                        arcpy.env.compression = "LZW"
                        
                        # Use Clip Management with ClippingGeometry (The Polygon)
                        # This handles the exact footprint intersection
                        arcpy.management.Clip(
                            in_raster=in_raster,
                            rectangle=f"{extent_poly.extent.XMin} {extent_poly.extent.YMin} {extent_poly.extent.XMax} {extent_poly.extent.YMax}", # Bounding box of projected poly
                            out_raster=temp_clipped,
                            in_template_dataset=temp_poly_fc, # USE THE FEATURE CLASS AS TEMPLATE
                            nodata_value="1",
                            clipping_geometry="ClippingGeometry", # FORCE USE GEOMETRY
                            maintain_clipping_extent="MAINTAIN_EXTENT"
                        )
                        
                        processing_raster = temp_clipped
                        messages.addMessage("      [OK] Input clipped to extent successfully.")
                        
                        # Cleanup poly
                        try: arcpy.management.Delete(temp_poly_fc)
                        except: pass
                        
                    except Exception as clip_err:
                        messages.addWarningMessage(f"      [WARN] Failed to clip to extent: {str(clip_err)}. Processing full raster.")
                        # Detailed debug info
                        try:
                            desc_r = arcpy.Describe(in_raster)
                            messages.addMessage(f"      [DEBUG] Raster SR: {desc_r.spatialReference.name} | Extent: {desc_r.extent}")
                            messages.addMessage(f"      [DEBUG] Env Extent: {old_extent}")
                        except: pass
                        processing_raster = in_raster
                else:
                    messages.addMessage("[INFO] No specific processing extent set. Processing full raster.")

                try:
                    # Run classification
                    output = arcpy.ia.ClassifyPixelsUsingDeepLearning(
                        in_raster=processing_raster,  # Use potentially clipped raster
                        in_model_definition=in_model,
                        arguments=args_str,
                        processing_mode=proc_mode
                    )
                    
                    # Save output (with TIFF workaround if needed)
                    try:
                        output.save(out_raster)
                    except RuntimeError as save_err:
                        if "010240" in str(save_err):
                            # Workaround: save as TIFF first, then convert
                            scratch_folder = arcpy.env.scratchFolder
                            temp_tiff = os.path.join(scratch_folder, f"temp_classify_{int(time.time())}.tif")
                            output.save(temp_tiff)
                            arcpy.management.CopyRaster(temp_tiff, out_raster)
                            try:
                                arcpy.management.Delete(temp_tiff)
                            except:
                                pass
                        else:
                            raise save_err
                    
                    elapsed = time.time() - start_time
                    messages.addMessage(f"[OK] Klasifikasi selesai dalam {elapsed:.1f} detik")
                    
                    # Cleanup temporary extracted raster
                    if temp_clipped:
                        try:
                            # Verify existence before delete
                            if arcpy.Exists(temp_clipped):
                                arcpy.management.Delete(temp_clipped)
                        except:
                            pass
                    
                except Exception as e:
                    # Fallback method (silent)
                    try:
                        output = arcpy.gp.ClassifyPixelsUsingDeepLearning(
                            in_raster, in_model, None, args_str, proc_mode
                        )
                        output.save(out_raster)
                    except:
                        raise e

            except Exception as e:
                raise e

            
            # ====================================================================
            # 7. POST-PROCESSING (POST-PROCESSING)
            # ====================================================================
            messages.addMessage("\n[3] POST-PROCESSING")
            messages.addMessage("-" * 60)
            
            try:
                # Calculate stats only once
                arcpy.management.CalculateStatistics(out_raster)
                arcpy.management.BuildPyramids(out_raster)
                messages.addMessage("[OK] Statistik: Dihitung")
                messages.addMessage("[OK] Piramida: Dibangun")
            except:
                pass  # Silent fail
            
            # ====================================================================
            # 8. CONVERT TO POLYGON (OPTIONAL)
            # ====================================================================
            if convert_to_polygon:
                messages.addMessage("\n[4] KONVERSI VEKTOR")
                messages.addMessage("-" * 60)
                try:
                    # Determine output name
                    out_dir = os.path.dirname(out_raster)
                    out_base = os.path.splitext(os.path.basename(out_raster))[0]
                    
                    if out_dir.endswith(".gdb") or ".gdb" in out_dir.lower():
                        # Output is inside a Geodatabase -> Feature Class
                        out_base_sanitized = out_base.replace(".", "_").replace("-", "_")
                        poly_name = os.path.join(out_dir, f"{out_base_sanitized}_Poly")
                    else:
                        # Output is in a folder -> Shapefile
                        poly_name = os.path.join(out_dir, f"{out_base}_Poly.shp")
                    
                    if arcpy.Exists(poly_name):
                        arcpy.Delete_management(poly_name)
                    
                    simplify_opt = "SIMPLIFY" if simplify_polygon else "NO_SIMPLIFY"
                    
                    # Optimization: Enable Parallel Processing for Vector Conversion
                    # (This is often CPU bound and safe to parallelize)
                    arcpy.env.parallelProcessingFactor = "100%"
                    
                    messages.addMessage(f"[INFO] Converting to polygon (Simplify: {simplify_polygon})...")
                    arcpy.conversion.RasterToPolygon(out_raster, poly_name, simplify_opt, "Value")
                    
                    # Add Fields and calculate attributes
                    arcpy.management.AddField(poly_name, "Class_Name", "TEXT", field_length=100)
                    arcpy.management.AddField(poly_name, "SNI_Class", "TEXT", field_length=100)
                    arcpy.management.AddField(poly_name, "Luas_Ha", "DOUBLE")
                    
                    # Calculate Fields
                    esri_classes = {
                        11: "Open Water",
                        12: "Perennial Snow/Ice",
                        21: "Developed, Open Space",
                        22: "Developed, Low Intensity",
                        23: "Developed, Medium Intensity",
                        24: "Developed, High Intensity",
                        31: "Barren Land",
                        41: "Deciduous Forest",
                        42: "Evergreen Forest",
                        43: "Mixed Forest",
                        52: "Shrub/Scrub",
                        71: "Herbaceous",
                        81: "Hay/Pasture",
                        82: "Cultivated Crops",
                        90: "Woody Wetlands",
                        95: "Emergent Herbaceous Wetlands"
                    }
                    
                    sni_mapping = {
                        11: "Air",
                        12: "Lainnya",
                        21: "Area Terbangun",
                        22: "Area Terbangun",
                        23: "Area Terbangun",
                        24: "Area Terbangun",
                        31: "Area Terbuka",
                        41: "Hutan",
                        42: "Hutan",
                        43: "Hutan",
                        52: "Area Terbuka",
                        71: "Area Terbuka",
                        81: "Pertanian (Sawah/Ladang)",
                        82: "Pertanian (Sawah/Ladang)",
                        90: "Rawa",
                        95: "Rawa"
                    }
                    
                    with arcpy.da.UpdateCursor(poly_name, ["gridcode", "Class_Name", "SNI_Class"]) as cursor:
                        for row in cursor:
                            grid_val = row[0]
                            row[1] = esri_classes.get(grid_val, f"Unknown ({grid_val})")
                            if output_standard.startswith("SNI"):
                                row[2] = sni_mapping.get(grid_val, "Lainnya")
                            else:
                                row[2] = row[1]
                            cursor.updateRow(row)
                    
                    # Calculate area
                    arcpy.management.CalculateGeometryAttributes(
                        in_features=poly_name,
                        geometry_property=[["Luas_Ha", "AREA_GEODESIC"]],
                        area_unit="HECTARES"
                    )
                    messages.addMessage("[OK] Vektor: Dibuat & Atribut Terisi")
                    
                    # Add to map
                    try:
                        aprx = arcpy.mp.ArcGISProject("CURRENT")
                        if aprx.activeMap:
                            aprx.activeMap.addDataFromPath(poly_name)
                    except:
                        pass
                        
                except Exception as e:
                    messages.addWarningMessage(f"[WARN] Konversi vektor gagal: {str(e)}")

            # ====================================================================
            # 9. CLEANUP
            # ====================================================================
            # messages.addMessage("\n[9] CLEANUP...")
            
            # Restore environment
            arcpy.env.workspace = old_workspace
            arcpy.env.cellSize = old_cellSize
            arcpy.env.extent = old_extent
            arcpy.env.scratchWorkspace = old_scratch
            
            # Check in license
            arcpy.CheckInExtension("ImageAnalyst")
            arcpy.CheckInExtension("Spatial")
            
            # Add to map if possible
            try:
                aprx = arcpy.mp.ArcGISProject("CURRENT")
                if aprx.activeMap:
                    aprx.activeMap.addDataFromPath(out_raster)
                    # messages.addMessage("[OK] Result added to map") # Silent ok
            except:
                pass
            
            # ====================================================================
            # 10. FINAL REPORT
            # ====================================================================
            messages.addMessage("")
            # Final check - ensure fix is applied even on repair
            # Final check - ensure fix is applied even on repair
            try:
                if "3.13" in sys.version:
                    self.apply_shadow_dll_fix(messages)
            except: pass

            messages.addMessage("\n" + "="*60)
            messages.addMessage(" PROSES SELESAI")
            messages.addMessage("="*60)
            messages.addMessage(f" Waktu Selesai : {time.strftime('%H:%M:%S')}")
            messages.addMessage("="*60)
            
        except Exception as e:
            messages.addErrorMessage(f"Terjadi kesalahan fatal: {str(e)}")
            messages.addErrorMessage(traceback.format_exc())

    
    def check_dependencies_preflight(self, messages):
        """Quick check for required dependencies"""
        required = ['torch', 'torchvision', 'fastai', 'cryptography']
        
        for dep in required:
            try:
                if dep == 'torch':
                    import torch
                    messages.addMessage(f"  [OK] PyTorch: {torch.__version__}")
                    # Check CUDA
                    if torch.cuda.is_available():
                        messages.addMessage(f"    CUDA: {torch.version.cuda}")
                elif dep == 'torchvision':
                    import torchvision
                    messages.addMessage(f"  [OK] TorchVision: {torchvision.__version__}")
                elif dep == 'fastai':
                    import fastai
                    messages.addMessage(f"  [OK] fastai: {fastai.__version__}")
                elif dep == 'cryptography':
                    import cryptography
                    messages.addMessage(f"  [OK] cryptography: {cryptography.__version__}")
            except ImportError:
                messages.addErrorMessage(f"  [ERR] {dep}: MISSING")
                return False
            except Exception as e:
                messages.addWarningMessage(f"  [WARN] {dep}: {str(e)}")
        
        return True

class ConvertDNtoReflectance(object):
    def __init__(self):
        """Define the tool (tool name is the class)."""
        self.label = "2. Koreksi Radiometrik (DN ke Reflectance)"
        self.category = "02. Pre-Processing"
        self.description = "Mengubah nilai piksel Digital Number (DN) menjadi Top-Of-Atmosphere (TOA) Reflectance menggunakan metadata satelit."
        self.canRunInBackground = False

    def getParameterInfo(self):
        """Define parameter definitions"""
        
        # Param 0: Input Raster (Level 1)
        param0 = arcpy.Parameter(
            displayName="Input Raster Level 1 (Mosaic Dataset / Raster dengan Metadata)",
            name="in_raster",
            datatype=["DEMosaicDataset", "GPRasterLayer", "DERasterDataset"],
            parameterType="Required",
            direction="Input"
        )
        
        # Param 1: Output Raster
        param1 = arcpy.Parameter(
            displayName="Output Raster Reflectance",
            name="out_raster",
            datatype="DERasterDataset",
            parameterType="Required",
            direction="Output"
        )
        
        # Param 2: Metadata File (MTL) - Optional/Required logic handled in Execute
        param2 = arcpy.Parameter(
            displayName="Metadata File (*_MTL.txt)",
            name="mtl_file",
            datatype="DEFile",
            parameterType="Optional",
            direction="Input"
        )
        # param2.filter.list = ["txt"] # Removed to allow all files (e.g. .TXT, .xml)

        return [param0, param1, param2]

    def isLicensed(self):
        """Set whether tool is licensed to execute."""
        return True

    def updateParameters(self, parameters):
        """Modify the values and properties of parameters before internal validation is performed."""
        return

    def updateMessages(self, parameters):
        """Modify the messages created by internal validation for each tool parameter."""
        return

    def execute(self, parameters, messages):
        """Execute the tool."""
        
        # Check License & Print Header
        valid, msg, info = SupabaseGuard.check_license()
        print_license_header(messages, info)
        
        try:
            in_raster = parameters[0].valueAsText
            out_raster = parameters[1].valueAsText
            mtl_file = parameters[2].valueAsText # New optional param
            
            # Header
            messages.addMessage("")
            messages.addMessage("=" * 60)
            messages.addMessage(f"KOREKSI RADIOMETRIK (DN -> REFLECTANCE) (v{CURRENT_VERSION})")
            messages.addMessage("=" * 60)
            
            # 1. Check License Availability
            messages.addMessage("\n[1] PEMERIKSAAN SISTEM")
            messages.addMessage("-" * 60)
            
            if arcpy.CheckExtension("ImageAnalyst") == "Available":
                arcpy.CheckOutExtension("ImageAnalyst")
                messages.addMessage("[OK] Lisensi: Image Analyst (Aktif)")
            elif arcpy.CheckExtension("Spatial") == "Available":
                arcpy.CheckOutExtension("Spatial")
                messages.addMessage("[OK] Lisensi: Spatial Analyst (Aktif)")
            else:
                messages.addErrorMessage("[ERR] Tidak ada lisensi Image Analyst atau Spatial Analyst!")
                raise arcpy.ExecuteError
            
            # 2. Processing
            messages.addMessage("\n[2] PEMROSESAN")
            messages.addMessage("-" * 60)
            messages.addMessage("Menghitung Apparent Reflectance (TOA)...")
            
            start_time = time.time()
            
            # ATTEMPT 1: Automatic (ApparentReflectance)
            # Works if input is a Raster Product or Mosaic Dataset with key properties
            success = False
            try:
                # Basic check: Does it have key properties?
                has_sun = False
                try:
                    props = arcpy.GetRasterProperties_management(in_raster, "SUN_ELEVATION")
                    if props: has_sun = True
                except: pass

                if has_sun or not mtl_file:
                    messages.addMessage("  Mencoba metode otomatis (Metadata Internal)...")
                    out_ref_raster = arcpy.ia.ApparentReflectance(in_raster)
                    messages.addMessage(f"  Menyimpan output ke: {os.path.basename(out_raster)}...")
                    out_ref_raster.save(out_raster)
                    success = True
            except Exception as e_auto:
                messages.addWarningMessage(f"  [INFO] Metode otomatis gagal: {str(e_auto)}")
                messages.addMessage("  Beralih ke metode Manual (menggunakan file MTL)...")
            
            # ATTEMPT 2: Manual Calculation (If Attempt 1 failed)
            if not success:
                if not mtl_file:
                    messages.addErrorMessage("[ERR] Metode otomatis gagal karena metadata (Sun Elevation) hilang.")
                    messages.addErrorMessage("       Mohon masukkan file metadata (*_MTL.txt/xml) di parameter.")
                    raise arcpy.ExecuteError("Missing Metadata File")
                
                if "ANG.txt" in mtl_file or "ang.txt" in mtl_file:
                    messages.addErrorMessage("[ERR] Anda memilih file '_ANG.txt'.") 
                    messages.addErrorMessage("       Harap pilih file metadata yang berakhiran '_MTL.txt'.")
                    raise arcpy.ExecuteError("Salah File Metadata")
                
                messages.addMessage("  Membaca parameter dari MTL File...")
                
                # A. Parse MTL
                sun_elev = None
                reflectance_mult_band = {}
                reflectance_add_band = {}
                
                import math
                
                with open(mtl_file, 'r') as f:
                    for line in f:
                        line = line.strip()
                        if "SUN_ELEVATION = " in line:
                            # Robust parsing like user snippet
                            left, sep, right = line.partition("SUN_ELEVATION = ")
                            if sep:
                                try:
                                    # Handle potential trailing garbage or quotes
                                    val_str = right.strip().replace('"', '')
                                    sun_elev = float(val_str)
                                except: pass
                                
                        elif "REFLECTANCE_MULT_BAND_" in line:
                            # REFLECTANCE_MULT_BAND_1 = 2.0000E-05
                            parts = line.split("=")
                            if len(parts) >= 2:
                                key = parts[0].strip() # REFLECTANCE_MULT_BAND_1
                                val_str = parts[1].strip().replace('"', '')
                                try:
                                    val = float(val_str)
                                    band_num = int(key.split("_")[-1])
                                    reflectance_mult_band[band_num] = val
                                except: pass
                                
                        elif "REFLECTANCE_ADD_BAND_" in line:
                            parts = line.split("=")
                            if len(parts) >= 2:
                                key = parts[0].strip()
                                val_str = parts[1].strip().replace('"', '')
                                try:
                                    val = float(val_str)
                                    band_num = int(key.split("_")[-1])
                                    reflectance_add_band[band_num] = val
                                except: pass
                            
                if sun_elev is None:
                     raise Exception("Gagal membaca SUN_ELEVATION dari file MTL. Pastikan file valid.")
                     
                messages.addMessage(f"  Sun Elevation: {sun_elev}")
                sin_theta = math.sin(math.radians(sun_elev))
                
                # B. Process Bands
                # Input raster is likely a composite. We need to access individual bands.
                # Assuming standard band order if composite: B1, B2, B3, B4, B5, B6, B7
                # Or user might have provided a folder of TIFs?
                # The parameter type is Raster Dataset, so it's one file/layer.
                
                messages.addMessage("  Melakukan kalkulasi per band...")
                
                # Get band count
                desc = arcpy.Describe(in_raster)
                band_count = desc.bandCount
                
                corrected_bands = []
                
                # We assume the composite follows numerical order 1..N
                # Band 1 in Composite corresponds to Band 1 in MTL? Usually yes if managed by this tool.
                
                temp_env = arcpy.env.scratchGDB if arcpy.env.scratchGDB else arcpy.env.scratchFolder
                
                # IMPORTANT: Only process multispectral bands (1-7)
                # Skip Band 8 (Panchromatic), Band 9 (Cirrus), Band 10-11 (Thermal)
                max_band = min(band_count, 7)  # Limit to Band 7
                
                for i in range(1, max_band + 1):
                    # Band names in composite are usually Band_1, Band_2...
                    band_raster = arcpy.sa.Raster(f"{in_raster}/Band_{i}")
                    
                    # Check if we have constants for this band
                    if i in reflectance_mult_band and i in reflectance_add_band:
                        M = reflectance_mult_band[i]
                        A = reflectance_add_band[i]
                        
                        # Formula: ((M * DN) + A) / sin(theta)
                        # TOA Reflectance
                        
                        # Handle NoData properly? 
                        # Calculation works on pixel values.
                        
                        raw_refl = ((M * band_raster) + A) / sin_theta
                        
                        # FIX: Clamp negative values to epsilon (0.0001) instead of 0
                        # This prevents ArcGIS from treating valid dark pixels as NoData (Transparent)
                        # raw_refl < 0 -> 0.0001
                        
                        refl_raster = arcpy.sa.Con(raw_refl < 0, 0.0001, raw_refl)
                        
                        corrected_bands.append(refl_raster)
                        # messages.addMessage(f"    Band {i}: OK")
                    else:
                        # Skip bands without constants (should not happen for Band 1-7)
                        messages.addWarningMessage(f"    Band {i}: Tidak ada konstanta di MTL, band diskip.")
                        # Do NOT append - skip this band entirely
                
                # C. Composite Result
                messages.addMessage(f"  Menyimpan hasil composite ({len(corrected_bands)} bands)...")
                arcpy.management.CompositeBands(corrected_bands, out_raster)
            
            elapsed = time.time() - start_time
            messages.addMessage(f"[OK] Selesai dalam {elapsed:.1f} detik")

            # 3. Finalization
            messages.addMessage("\n[3] FINALISASI")
            messages.addMessage("-" * 60)
            
            try:
                arcpy.management.CalculateStatistics(out_raster)
                messages.addMessage("[OK] Statistik Dihitung")
            except: pass
            
            try:
                arcpy.management.BuildPyramids(out_raster)
                messages.addMessage("[OK] Piramida Dibangun")
            except: pass

            messages.addMessage("=" * 60)
            messages.addMessage(" PROSES SELESAI")
            messages.addMessage("=" * 60)
            
            # Add to map
            try:
                aprx = arcpy.mp.ArcGISProject("CURRENT")
                if aprx.activeMap:
                    aprx.activeMap.addDataFromPath(out_raster)
            except: pass

        except Exception as e:
            messages.addErrorMessage(f"Error: {str(e)}")
            raise arcpy.ExecuteError
        finally:
            try:
                arcpy.CheckInExtension("ImageAnalyst")
                arcpy.CheckInExtension("Spatial")
            except: pass
